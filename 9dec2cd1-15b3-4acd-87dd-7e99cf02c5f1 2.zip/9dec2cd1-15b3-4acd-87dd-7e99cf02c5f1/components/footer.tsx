import Link from 'next/link'
import { Phone, Mail, MapPin, Scale } from 'lucide-react'

export default function Footer() {
  return (
    <footer className="bg-[#1B3A57] text-white">
      <div className="container mx-auto px-4 py-12">
        <div className="grid md:grid-cols-4 gap-8">
          {/* About */}
          <div>
            <h3 className="text-xl font-serif font-bold mb-4 text-[#B8935E]">
              María de los Ángeles Mena C.
            </h3>
            <p className="text-sm text-[#F5F1E8]/80 leading-relaxed mb-4">
              Licenciada en Derecho, Pontificia Universidad Católica de Chile. Servicios jurídicos especializados con calidad humana.
            </p>
            <div className="flex items-center gap-2 text-sm text-[#F5F1E8]/80">
              <Scale className="w-4 h-4 text-[#B8935E]" />
              <span>Legal Tech & AI Expertise</span>
            </div>
          </div>

          {/* Practice Areas */}
          <div>
            <h4 className="font-semibold mb-4 text-[#B8935E]">Áreas de Práctica</h4>
            <ul className="space-y-2 text-sm">
              <li>
                <Link href="/derecho-de-familia" className="text-[#F5F1E8]/80 hover:text-white transition-colors">
                  Derecho de Familia
                </Link>
              </li>
              <li>
                <Link href="/contratos-privados" className="text-[#F5F1E8]/80 hover:text-white transition-colors">
                  Contratos Privados
                </Link>
              </li>
              <li>
                <Link href="/negligencias-medicas" className="text-[#F5F1E8]/80 hover:text-white transition-colors">
                  Negligencias Médicas
                </Link>
              </li>
              <li>
                <Link href="/herencias-sucesiones" className="text-[#F5F1E8]/80 hover:text-white transition-colors">
                  Herencias y Sucesiones
                </Link>
              </li>
            </ul>
          </div>

          {/* Quick Links */}
          <div>
            <h4 className="font-semibold mb-4 text-[#B8935E]">Enlaces Rápidos</h4>
            <ul className="space-y-2 text-sm">
              <li>
                <Link href="/nuestro-estudio" className="text-[#F5F1E8]/80 hover:text-white transition-colors">
                  Nuestro Estudio
                </Link>
              </li>
              <li>
                <Link href="/regiones" className="text-[#F5F1E8]/80 hover:text-white transition-colors">
                  Regiones que Atendemos
                </Link>
              </li>
              <li>
                <Link href="/casos-de-exito" className="text-[#F5F1E8]/80 hover:text-white transition-colors">
                  Casos de Éxito
                </Link>
              </li>
              <li>
                <Link href="/blog" className="text-[#F5F1E8]/80 hover:text-white transition-colors">
                  Blog Jurídico
                </Link>
              </li>
              <li>
                <Link href="/contacto" className="text-[#F5F1E8]/80 hover:text-white transition-colors">
                  Contacto
                </Link>
              </li>
            </ul>
          </div>

          {/* Contact Info */}
          <div>
            <h4 className="font-semibold mb-4 text-[#B8935E]">Contacto</h4>
            <ul className="space-y-3 text-sm">
              <li className="flex items-start gap-2">
                <Phone className="w-4 h-4 mt-1 text-[#B8935E] flex-shrink-0" />
                <a href="tel:+56912345678" className="text-[#F5F1E8]/80 hover:text-white transition-colors">
                  +56 9 1234 5678
                </a>
              </li>
              <li className="flex items-start gap-2">
                <Mail className="w-4 h-4 mt-1 text-[#B8935E] flex-shrink-0" />
                <a href="mailto:contacto@menalegal.cl" className="text-[#F5F1E8]/80 hover:text-white transition-colors break-all">
                  contacto@menalegal.cl
                </a>
              </li>
              <li className="flex items-start gap-2">
                <MapPin className="w-4 h-4 mt-1 text-[#B8935E] flex-shrink-0" />
                <span className="text-[#F5F1E8]/80">
                  Región Metropolitana, O'Higgins, Valparaíso
                </span>
              </li>
            </ul>
            <div className="mt-4 p-3 bg-white/5 rounded">
              <p className="text-xs text-[#F5F1E8]/80">
                <strong className="text-white">Horario:</strong><br />
                Lun - Vie: 9:00 - 19:00<br />
                Sáb: 9:00 - 13:00
              </p>
            </div>
          </div>
        </div>

        {/* Bottom Bar */}
        <div className="border-t border-white/10 mt-8 pt-8 text-center">
          <p className="text-sm text-[#F5F1E8]/60">
            © {new Date().getFullYear()} María de los Ángeles Mena C. - Todos los derechos reservados
          </p>
          <p className="text-xs text-[#F5F1E8]/40 mt-2">
            Generated by Superagent.
          </p>
        </div>
      </div>
    </footer>
  )
}
