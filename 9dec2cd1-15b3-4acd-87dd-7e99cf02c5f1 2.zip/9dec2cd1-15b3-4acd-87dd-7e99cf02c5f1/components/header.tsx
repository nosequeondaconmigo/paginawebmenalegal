'use client'

import Link from 'next/link'
import { useState } from 'react'
import { Button } from '@/components/ui/button'
import { Phone, Mail, Menu, X, ChevronDown } from 'lucide-react'
import {
  NavigationMenu,
  NavigationMenuContent,
  NavigationMenuItem,
  NavigationMenuLink,
  NavigationMenuList,
  NavigationMenuTrigger,
} from "@/components/ui/navigation-menu"

export default function Header() {
  const [mobileMenuOpen, setMobileMenuOpen] = useState(false)

  return (
    <header className="sticky top-0 z-50 bg-white border-b border-[#1B3A57]/10 shadow-sm">
      {/* Top Bar */}
      <div className="bg-[#1B3A57] text-white py-2">
        <div className="container mx-auto px-4">
          <div className="flex flex-col sm:flex-row justify-between items-center gap-2 text-sm">
            <div className="flex items-center gap-4">
              <a href="tel:+56912345678" className="flex items-center gap-2 hover:text-[#B8935E] transition-colors">
                <Phone className="w-4 h-4" />
                <span>+56 9 1234 5678</span>
              </a>
              <a href="mailto:contacto@menalegal.cl" className="flex items-center gap-2 hover:text-[#B8935E] transition-colors">
                <Mail className="w-4 h-4" />
                <span className="hidden sm:inline">contacto@menalegal.cl</span>
              </a>
            </div>
            <div className="text-xs sm:text-sm">
              Lun - Vie: 9:00 - 19:00 | Sáb: 9:00 - 13:00
            </div>
          </div>
        </div>
      </div>

      {/* Main Navigation */}
      <div className="container mx-auto px-4">
        <div className="flex items-center justify-between py-4">
          {/* Logo */}
          <Link href="/" className="flex flex-col">
            <span className="text-xl md:text-2xl font-serif font-bold text-[#1B3A57]">
              María de los Ángeles Mena C.
            </span>
            <span className="text-xs md:text-sm text-[#2C2C2C]">
              Licenciada en Derecho · Pontificia Universidad Católica de Chile
            </span>
          </Link>

          {/* Desktop Navigation */}
          <nav className="hidden lg:block">
            <NavigationMenu>
              <NavigationMenuList className="gap-1">
                <NavigationMenuItem>
                  <Link href="/" legacyBehavior passHref>
                    <NavigationMenuLink className="px-4 py-2 text-[#2C2C2C] hover:text-[#B8935E] font-medium transition-colors">
                      Inicio
                    </NavigationMenuLink>
                  </Link>
                </NavigationMenuItem>

                <NavigationMenuItem>
                  <Link href="/nuestro-estudio" legacyBehavior passHref>
                    <NavigationMenuLink className="px-4 py-2 text-[#2C2C2C] hover:text-[#B8935E] font-medium transition-colors">
                      Nuestro Estudio
                    </NavigationMenuLink>
                  </Link>
                </NavigationMenuItem>

                <NavigationMenuItem>
                  <NavigationMenuTrigger className="px-4 py-2 text-[#2C2C2C] hover:text-[#B8935E] font-medium">
                    Áreas de Práctica
                  </NavigationMenuTrigger>
                  <NavigationMenuContent>
                    <ul className="grid w-[400px] gap-3 p-4">
                      <li>
                        <Link href="/derecho-de-familia" legacyBehavior passHref>
                          <NavigationMenuLink className="block select-none space-y-1 rounded-md p-3 leading-none no-underline outline-none transition-colors hover:bg-[#F5F1E8] hover:text-[#1B3A57] focus:bg-[#F5F1E8]">
                            <div className="text-sm font-semibold leading-none">Derecho de Familia</div>
                            <p className="line-clamp-2 text-sm leading-snug text-muted-foreground">
                              Divorcio, custodia, alimentos
                            </p>
                          </NavigationMenuLink>
                        </Link>
                      </li>
                      <li>
                        <Link href="/contratos-privados" legacyBehavior passHref>
                          <NavigationMenuLink className="block select-none space-y-1 rounded-md p-3 leading-none no-underline outline-none transition-colors hover:bg-[#F5F1E8] hover:text-[#1B3A57] focus:bg-[#F5F1E8]">
                            <div className="text-sm font-semibold leading-none">Contratos Privados</div>
                            <p className="line-clamp-2 text-sm leading-snug text-muted-foreground">
                              Redacción, revisión, negociación
                            </p>
                          </NavigationMenuLink>
                        </Link>
                      </li>
                      <li>
                        <Link href="/negligencias-medicas" legacyBehavior passHref>
                          <NavigationMenuLink className="block select-none space-y-1 rounded-md p-3 leading-none no-underline outline-none transition-colors hover:bg-[#F5F1E8] hover:text-[#1B3A57] focus:bg-[#F5F1E8]">
                            <div className="text-sm font-semibold leading-none">Negligencias Médicas</div>
                            <p className="line-clamp-2 text-sm leading-snug text-muted-foreground">
                              Derechos del paciente, reclamos
                            </p>
                          </NavigationMenuLink>
                        </Link>
                      </li>
                      <li>
                        <Link href="/herencias-sucesiones" legacyBehavior passHref>
                          <NavigationMenuLink className="block select-none space-y-1 rounded-md p-3 leading-none no-underline outline-none transition-colors hover:bg-[#F5F1E8] hover:text-[#1B3A57] focus:bg-[#F5F1E8]">
                            <div className="text-sm font-semibold leading-none">Herencias y Sucesiones</div>
                            <p className="line-clamp-2 text-sm leading-snug text-muted-foreground">
                              Testamentos, posesión efectiva
                            </p>
                          </NavigationMenuLink>
                        </Link>
                      </li>
                    </ul>
                  </NavigationMenuContent>
                </NavigationMenuItem>

                <NavigationMenuItem>
                  <Link href="/regiones" legacyBehavior passHref>
                    <NavigationMenuLink className="px-4 py-2 text-[#2C2C2C] hover:text-[#B8935E] font-medium transition-colors">
                      Regiones
                    </NavigationMenuLink>
                  </Link>
                </NavigationMenuItem>

                <NavigationMenuItem>
                  <Link href="/blog" legacyBehavior passHref>
                    <NavigationMenuLink className="px-4 py-2 text-[#2C2C2C] hover:text-[#B8935E] font-medium transition-colors">
                      Blog
                    </NavigationMenuLink>
                  </Link>
                </NavigationMenuItem>

                <NavigationMenuItem>
                  <Link href="/contacto">
                    <Button className="bg-[#B8935E] hover:bg-[#A07D4A] text-white ml-2">
                      Contacto
                    </Button>
                  </Link>
                </NavigationMenuItem>
              </NavigationMenuList>
            </NavigationMenu>
          </nav>

          {/* Mobile Menu Button */}
          <button
            className="lg:hidden p-2 text-[#1B3A57]"
            onClick={() => setMobileMenuOpen(!mobileMenuOpen)}
          >
            {mobileMenuOpen ? <X className="w-6 h-6" /> : <Menu className="w-6 h-6" />}
          </button>
        </div>

        {/* Mobile Navigation */}
        {mobileMenuOpen && (
          <nav className="lg:hidden pb-4 border-t border-[#1B3A57]/10 mt-2">
            <div className="flex flex-col gap-2 pt-4">
              <Link href="/" className="px-4 py-2 text-[#2C2C2C] hover:bg-[#F5F1E8] rounded" onClick={() => setMobileMenuOpen(false)}>
                Inicio
              </Link>
              <Link href="/nuestro-estudio" className="px-4 py-2 text-[#2C2C2C] hover:bg-[#F5F1E8] rounded" onClick={() => setMobileMenuOpen(false)}>
                Nuestro Estudio
              </Link>
              <div className="px-4 py-2 font-semibold text-[#1B3A57] text-sm">Áreas de Práctica</div>
              <Link href="/derecho-de-familia" className="px-8 py-2 text-[#2C2C2C] hover:bg-[#F5F1E8] rounded text-sm" onClick={() => setMobileMenuOpen(false)}>
                Derecho de Familia
              </Link>
              <Link href="/contratos-privados" className="px-8 py-2 text-[#2C2C2C] hover:bg-[#F5F1E8] rounded text-sm" onClick={() => setMobileMenuOpen(false)}>
                Contratos Privados
              </Link>
              <Link href="/negligencias-medicas" className="px-8 py-2 text-[#2C2C2C] hover:bg-[#F5F1E8] rounded text-sm" onClick={() => setMobileMenuOpen(false)}>
                Negligencias Médicas
              </Link>
              <Link href="/herencias-sucesiones" className="px-8 py-2 text-[#2C2C2C] hover:bg-[#F5F1E8] rounded text-sm" onClick={() => setMobileMenuOpen(false)}>
                Herencias y Sucesiones
              </Link>
              <Link href="/regiones" className="px-4 py-2 text-[#2C2C2C] hover:bg-[#F5F1E8] rounded" onClick={() => setMobileMenuOpen(false)}>
                Regiones
              </Link>
              <Link href="/blog" className="px-4 py-2 text-[#2C2C2C] hover:bg-[#F5F1E8] rounded" onClick={() => setMobileMenuOpen(false)}>
                Blog
              </Link>
              <Link href="/contacto" className="mx-4 mt-2" onClick={() => setMobileMenuOpen(false)}>
                <Button className="bg-[#B8935E] hover:bg-[#A07D4A] text-white w-full">
                  Contacto
                </Button>
              </Link>
            </div>
          </nav>
        )}
      </div>
    </header>
  )
}
