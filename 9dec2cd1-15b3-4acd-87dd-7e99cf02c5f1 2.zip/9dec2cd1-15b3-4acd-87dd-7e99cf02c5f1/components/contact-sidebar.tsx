import { Card, CardContent } from '@/components/ui/card'
import { Phone, Mail, Clock, MessageCircle } from 'lucide-react'

export default function ContactSidebar() {
  return (
    <div className="sticky top-24 space-y-6">
      <Card className="border-2 border-[#B8935E]">
        <CardContent className="p-6">
          <h3 className="text-xl font-serif font-bold mb-4 text-[#1B3A57]">
            Contacto Rápido
          </h3>
          
          <div className="space-y-4">
            <a 
              href="https://wa.me/56912345678" 
              target="_blank" 
              rel="noopener noreferrer"
              className="flex items-center gap-3 p-3 bg-[#25D366] text-white rounded-lg hover:bg-[#20BA5A] transition-colors"
            >
              <MessageCircle className="w-5 h-5" />
              <div>
                <div className="font-semibold text-sm">WhatsApp</div>
                <div className="text-xs">Respuesta Rápida</div>
              </div>
            </a>

            <a 
              href="tel:+56912345678"
              className="flex items-center gap-3 p-3 bg-[#B8935E] text-white rounded-lg hover:bg-[#A07D4A] transition-colors"
            >
              <Phone className="w-5 h-5" />
              <div>
                <div className="font-semibold text-sm">+56 9 1234 5678</div>
                <div className="text-xs">Llamar Ahora</div>
              </div>
            </a>

            <a 
              href="mailto:contacto@menalegal.cl"
              className="flex items-center gap-3 p-3 bg-[#1B3A57] text-white rounded-lg hover:bg-[#2A4A67] transition-colors"
            >
              <Mail className="w-5 h-5" />
              <div>
                <div className="font-semibold text-sm text-pretty">contacto@menalegal.cl</div>
                <div className="text-xs">Email</div>
              </div>
            </a>
          </div>
        </CardContent>
      </Card>

      <Card className="border-2 border-[#1B3A57]/10 bg-[#F5F1E8]">
        <CardContent className="p-6">
          <div className="flex items-start gap-3 mb-3">
            <Clock className="w-5 h-5 text-[#B8935E]" />
            <h4 className="font-semibold text-[#1B3A57]">Horario</h4>
          </div>
          <div className="text-sm text-[#2C2C2C] space-y-1">
            <p><strong>Lun - Vie:</strong> 9:00 - 19:00</p>
            <p><strong>Sábado:</strong> 9:00 - 13:00</p>
            <p><strong>Domingo:</strong> Cerrado</p>
          </div>
        </CardContent>
      </Card>

      <Card className="border-2 border-[#1B3A57]/10">
        <CardContent className="p-6">
          <h4 className="font-semibold text-[#1B3A57] mb-3">Regiones Servidas</h4>
          <ul className="text-sm text-[#2C2C2C] space-y-2">
            <li>• Región Metropolitana</li>
            <li>• Región de O'Higgins</li>
            <li>• Región de Valparaíso</li>
          </ul>
        </CardContent>
      </Card>
    </div>
  )
}
