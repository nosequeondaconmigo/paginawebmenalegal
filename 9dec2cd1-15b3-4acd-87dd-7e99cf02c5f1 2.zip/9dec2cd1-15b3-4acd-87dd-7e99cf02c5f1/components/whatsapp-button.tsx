'use client'

import { MessageCircle } from 'lucide-react'
import { useState, useEffect } from 'react'

export default function WhatsAppButton() {
  const [isVisible, setIsVisible] = useState(true)
  const [isOnline, setIsOnline] = useState(false)

  useEffect(() => {
    // Check if current time is within business hours (Chile time)
    const checkBusinessHours = () => {
      const now = new Date()
      const hours = now.getHours()
      const day = now.getDay()
      
      // Monday-Friday 9:00-19:00 or Saturday 9:00-13:00
      const isMondayToFriday = day >= 1 && day <= 5 && hours >= 9 && hours < 19
      const isSaturday = day === 6 && hours >= 9 && hours < 13
      
      setIsOnline(isMondayToFriday || isSaturday)
    }

    checkBusinessHours()
    const interval = setInterval(checkBusinessHours, 60000) // Check every minute

    return () => clearInterval(interval)
  }, [])

  const whatsappNumber = '56912345678' // Replace with actual number
  const message = encodeURIComponent('Hola, necesito asesoría legal. ¿Pueden ayudarme?')
  const whatsappUrl = `https://wa.me/${whatsappNumber}?text=${message}`

  return (
    <a
      href={whatsappUrl}
      target="_blank"
      rel="noopener noreferrer"
      className="fixed bottom-6 right-6 z-50 group"
      aria-label="Contactar por WhatsApp"
    >
      <div className="relative">
        {/* Badge */}
        {isOnline && (
          <div className="absolute -top-2 -right-2 bg-green-500 text-white text-xs font-semibold px-2 py-1 rounded-full shadow-lg whitespace-nowrap z-10">
            En Línea
          </div>
        )}
        
        {/* Main Button */}
        <div className="bg-[#25D366] text-white p-4 rounded-full shadow-lg hover:shadow-xl transition-all hover:scale-110 active:scale-95">
          <MessageCircle className="w-8 h-8" />
        </div>

        {/* Pulse Animation */}
        <div className="absolute inset-0 bg-[#25D366] rounded-full animate-ping opacity-20"></div>
      </div>

      {/* Tooltip */}
      <div className="absolute right-full mr-3 top-1/2 -translate-y-1/2 bg-gray-900 text-white px-3 py-2 rounded-lg text-sm whitespace-nowrap opacity-0 group-hover:opacity-100 transition-opacity pointer-events-none">
        Respuesta Rápida
        <div className="absolute top-1/2 -translate-y-1/2 -right-1 w-2 h-2 bg-gray-900 rotate-45"></div>
      </div>
    </a>
  )
}
