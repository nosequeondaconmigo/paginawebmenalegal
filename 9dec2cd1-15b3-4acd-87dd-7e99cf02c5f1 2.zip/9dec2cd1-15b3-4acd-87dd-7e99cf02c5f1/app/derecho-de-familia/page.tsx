import { Card, CardContent } from '@/components/ui/card'
import { Button } from '@/components/ui/button'
import { Check, Heart, Scale, Users, FileText, Shield } from 'lucide-react'
import Link from 'next/link'
import ContactSidebar from '@/components/contact-sidebar'
import {
  Accordion,
  AccordionContent,
  AccordionItem,
  AccordionTrigger,
} from "@/components/ui/accordion"
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs"

export const metadata = {
  title: 'Derecho de Familia | María de los Ángeles Mena C.',
  description: 'Asesoría especializada en Derecho de Familia en Chile: divorcio, custodia, alimentos, compensación económica. Servicio en RM, O\'Higgins y Valparaíso.',
}

export default function DerechoDeFamilia() {
  return (
    <div className="min-h-screen">
      {/* Hero Section */}
      <section className="relative bg-gradient-to-br from-[#1B3A57] via-[#2A4A67] to-[#1B3A57] text-white py-20">
        <div className="container mx-auto px-4">
          <div className="max-w-4xl mx-auto text-center">
            <h1 className="text-4xl md:text-5xl font-serif font-bold mb-6 text-balance">
              Derecho de Familia: Asesoría Jurídica con Empatía y Profesionalismo
            </h1>
            <p className="text-xl mb-8 text-[#F5F1E8]/90 leading-relaxed">
              Proteja los derechos de su familia con asesoría especializada y trato humano
            </p>
            <Link href="/contacto">
              <Button size="lg" className="bg-[#B8935E] hover:bg-[#A07D4A] text-white font-semibold px-8 py-6 text-lg">
                Agendar Consulta Gratuita
              </Button>
            </Link>
          </div>
        </div>
      </section>

      <div className="container mx-auto px-4 py-16">
        <div className="grid lg:grid-cols-3 gap-8">
          {/* Main Content */}
          <div className="lg:col-span-2 space-y-12">
            {/* Marco Legal Chileno */}
            <section>
              <h2 className="text-3xl font-serif font-bold mb-6 text-[#1B3A57]">
                Marco Legal en Chile
              </h2>
              <Card className="border-2 border-[#1B3A57]/10">
                <CardContent className="p-6">
                  <div className="prose prose-lg max-w-none">
                    <p className="text-[#2C2C2C] leading-relaxed mb-4">
                      El divorcio se legalizó en Chile en 2004, estableciendo tres vías principales:
                    </p>
                    <ul className="space-y-3 text-[#2C2C2C]">
                      <li className="flex items-start gap-2">
                        <Check className="w-5 h-5 text-[#B8935E] mt-1 flex-shrink-0" />
                        <span><strong>Divorcio por mutuo acuerdo:</strong> Requiere 1 año de separación</span>
                      </li>
                      <li className="flex items-start gap-2">
                        <Check className="w-5 h-5 text-[#B8935E] mt-1 flex-shrink-0" />
                        <span><strong>Divorcio unilateral:</strong> Requiere 3 años de separación</span>
                      </li>
                      <li className="flex items-start gap-2">
                        <Check className="w-5 h-5 text-[#B8935E] mt-1 flex-shrink-0" />
                        <span><strong>Divorcio culposo:</strong> Sin periodo de espera, basado en causales específicas</span>
                      </li>
                    </ul>
                    <p className="text-[#2C2C2C] leading-relaxed mt-4">
                      En Chile, la <strong>compensación económica</strong> es un concepto único que opera independiente del régimen matrimonial, diseñado para equilibrar el menoscabo económico sufrido por uno de los cónyuges.
                    </p>
                  </div>
                </CardContent>
              </Card>
            </section>

            {/* Servicios Ofrecidos */}
            <section>
              <h2 className="text-3xl font-serif font-bold mb-6 text-[#1B3A57]">
                Servicios Especializados
              </h2>
              <div className="grid md:grid-cols-2 gap-4">
                {[
                  { icon: Heart, title: 'Divorcio', desc: 'Mutuo acuerdo y unilateral' },
                  { icon: Scale, title: 'Compensación Económica', desc: 'Cálculo y negociación' },
                  { icon: Users, title: 'Cuidado Personal', desc: 'Custodia y régimen de visitas' },
                  { icon: FileText, title: 'Pensión Alimenticia', desc: 'Determinación y cumplimiento' },
                  { icon: Shield, title: 'Violencia Intrafamiliar', desc: 'Medidas cautelares y protección' },
                  { icon: FileText, title: 'Liquidación Sociedad Conyugal', desc: 'División de bienes' },
                ].map((servicio, idx) => (
                  <Card key={idx} className="border-2 border-[#1B3A57]/10 hover:border-[#B8935E] transition-colors">
                    <CardContent className="p-4">
                      <div className="flex items-start gap-3">
                        <div className="w-10 h-10 bg-[#B8935E]/10 rounded-full flex items-center justify-center flex-shrink-0">
                          <servicio.icon className="w-5 h-5 text-[#B8935E]" />
                        </div>
                        <div>
                          <h3 className="font-semibold text-[#1B3A57] mb-1">{servicio.title}</h3>
                          <p className="text-sm text-[#2C2C2C]">{servicio.desc}</p>
                        </div>
                      </div>
                    </CardContent>
                  </Card>
                ))}
              </div>
            </section>

            {/* Proceso y Plazos */}
            <section>
              <h2 className="text-3xl font-serif font-bold mb-6 text-[#1B3A57]">
                Proceso y Plazos
              </h2>
              <Card className="border-2 border-[#1B3A57]/10">
                <CardContent className="p-6">
                  <div className="space-y-6">
                    {[
                      { step: '1', title: 'Consulta Inicial', desc: 'Evaluación de su caso y estrategia legal', time: '1-2 días' },
                      { step: '2', title: 'Preparación Documentación', desc: 'Recopilación de documentos necesarios', time: '1-2 semanas' },
                      { step: '3', title: 'Mediación Obligatoria', desc: 'Intento de acuerdo extrajudicial', time: '1-2 meses' },
                      { step: '4', title: 'Demanda Judicial', desc: 'Presentación ante tribunales de familia', time: '1 semana' },
                      { step: '5', title: 'Audiencias', desc: 'Preparación y acompañamiento en audiencias', time: '3-6 meses' },
                      { step: '6', title: 'Sentencia', desc: 'Resolución judicial del caso', time: 'Variable' },
                    ].map((fase) => (
                      <div key={fase.step} className="flex gap-4">
                        <div className="flex-shrink-0">
                          <div className="w-12 h-12 bg-[#B8935E] rounded-full flex items-center justify-center text-white font-bold">
                            {fase.step}
                          </div>
                        </div>
                        <div className="flex-1">
                          <h3 className="font-semibold text-[#1B3A57] mb-1">{fase.title}</h3>
                          <p className="text-sm text-[#2C2C2C] mb-1">{fase.desc}</p>
                          <p className="text-xs text-[#B8935E] font-semibold">Tiempo estimado: {fase.time}</p>
                        </div>
                      </div>
                    ))}
                  </div>
                  <div className="mt-6 p-4 bg-[#F5F1E8] rounded-lg">
                    <p className="text-sm text-[#2C2C2C]">
                      <strong>Plazos aproximados:</strong><br />
                      • Divorcio mutuo acuerdo: 6-12 meses<br />
                      • Divorcio unilateral: 12-24 meses
                    </p>
                  </div>
                </CardContent>
              </Card>
            </section>

            {/* Mensajería Regional */}
            <section>
              <h2 className="text-3xl font-serif font-bold mb-6 text-[#1B3A57]">
                Servicio por Región
              </h2>
              <Tabs defaultValue="metropolitana" className="w-full">
                <TabsList className="grid w-full grid-cols-3">
                  <TabsTrigger value="metropolitana">RM</TabsTrigger>
                  <TabsTrigger value="ohiggins">O'Higgins</TabsTrigger>
                  <TabsTrigger value="valparaiso">Valparaíso</TabsTrigger>
                </TabsList>
                <TabsContent value="metropolitana">
                  <Card className="border-2 border-[#1B3A57]/10">
                    <CardContent className="p-6">
                      <h3 className="text-xl font-serif font-bold mb-3 text-[#1B3A57]">
                        Región Metropolitana
                      </h3>
                      <p className="text-[#2C2C2C] leading-relaxed">
                        Soluciones legales eficientes para el ritmo de Santiago. Asesoría experta y ágil para proteger sus intereses familiares con atención presencial en nuestra oficina principal.
                      </p>
                    </CardContent>
                  </Card>
                </TabsContent>
                <TabsContent value="ohiggins">
                  <Card className="border-2 border-[#1B3A57]/10">
                    <CardContent className="p-6">
                      <h3 className="text-xl font-serif font-bold mb-3 text-[#1B3A57]">
                        Región de O'Higgins
                      </h3>
                      <p className="text-[#2C2C2C] leading-relaxed">
                        Asesoría legal de confianza en el corazón de O'Higgins. Servicio cercano y profesional con reuniones presenciales estratégicas y atención remota completa.
                      </p>
                    </CardContent>
                  </Card>
                </TabsContent>
                <TabsContent value="valparaiso">
                  <Card className="border-2 border-[#1B3A57]/10">
                    <CardContent className="p-6">
                      <h3 className="text-xl font-serif font-bold mb-3 text-[#1B3A57]">
                        Región de Valparaíso
                      </h3>
                      <p className="text-[#2C2C2C] leading-relaxed">
                        Defensa estratégica en Valparaíso. Experiencia para navegar los desafíos legales de la región con atención personalizada presencial y remota.
                      </p>
                    </CardContent>
                  </Card>
                </TabsContent>
              </Tabs>
            </section>

            {/* FAQ */}
            <section>
              <h2 className="text-3xl font-serif font-bold mb-6 text-[#1B3A57]">
                Preguntas Frecuentes
              </h2>
              <Accordion type="single" collapsible className="w-full">
                <AccordionItem value="item-1">
                  <AccordionTrigger className="text-left">
                    ¿Cuánto tiempo toma un divorcio en Chile?
                  </AccordionTrigger>
                  <AccordionContent className="text-[#2C2C2C] leading-relaxed">
                    El tiempo varía según el tipo de divorcio. Un divorcio por mutuo acuerdo puede tomar entre 6-12 meses, mientras que uno unilateral puede extenderse de 12-24 meses. Los plazos dependen de la carga del tribunal y la complejidad del caso.
                  </AccordionContent>
                </AccordionItem>

                <AccordionItem value="item-2">
                  <AccordionTrigger className="text-left">
                    ¿Qué es la compensación económica?
                  </AccordionTrigger>
                  <AccordionContent className="text-[#2C2C2C] leading-relaxed">
                    Es un derecho único del derecho chileno que busca equilibrar el menoscabo económico sufrido por uno de los cónyuges durante el matrimonio. Se calcula considerando factores como la duración del matrimonio, la situación patrimonial de ambos, y el esfuerzo dedicado al cuidado de los hijos.
                  </AccordionContent>
                </AccordionItem>

                <AccordionItem value="item-3">
                  <AccordionTrigger className="text-left">
                    ¿Cómo se determina la custodia de los hijos?
                  </AccordionTrigger>
                  <AccordionContent className="text-[#2C2C2C] leading-relaxed">
                    El tribunal determina el cuidado personal de los hijos basándose en el interés superior del niño. Se consideran factores como la vinculación afectiva, la capacidad de cada padre para satisfacer las necesidades del menor, y la opinión del niño según su edad y madurez.
                  </AccordionContent>
                </AccordionItem>

                <AccordionItem value="item-4">
                  <AccordionTrigger className="text-left">
                    ¿Es obligatoria la mediación antes del divorcio?
                  </AccordionTrigger>
                  <AccordionContent className="text-[#2C2C2C] leading-relaxed">
                    Sí, en Chile es obligatorio intentar una mediación antes de iniciar un juicio de divorcio. Este proceso busca llegar a acuerdos sobre materias como el cuidado de los hijos, pensión alimenticia y división de bienes de forma más rápida y menos conflictiva.
                  </AccordionContent>
                </AccordionItem>

                <AccordionItem value="item-5">
                  <AccordionTrigger className="text-left">
                    ¿Puedo modificar la pensión alimenticia después de establecida?
                  </AccordionTrigger>
                  <AccordionContent className="text-[#2C2C2C] leading-relaxed">
                    Sí, la pensión alimenticia puede ser modificada cuando exista un cambio sustancial en las circunstancias económicas del alimentante o en las necesidades del alimentario. Se debe presentar una nueva demanda ante el tribunal de familia.
                  </AccordionContent>
                </AccordionItem>
              </Accordion>
            </section>

            {/* CTA */}
            <Card className="bg-[#1B3A57] text-white border-none">
              <CardContent className="p-8 text-center">
                <h3 className="text-2xl font-serif font-bold mb-4">
                  Proteja los Derechos de Su Familia
                </h3>
                <p className="mb-6 text-[#F5F1E8]/90 leading-relaxed">
                  Agende una consulta gratuita para discutir su caso con una abogada especializada
                </p>
                <Link href="/contacto">
                  <Button size="lg" className="bg-[#B8935E] hover:bg-[#A07D4A] text-white font-semibold px-8">
                    Solicitar Consulta
                  </Button>
                </Link>
              </CardContent>
            </Card>
          </div>

          {/* Sidebar */}
          <div className="lg:col-span-1">
            <ContactSidebar />
          </div>
        </div>
      </div>
    </div>
  )
}
