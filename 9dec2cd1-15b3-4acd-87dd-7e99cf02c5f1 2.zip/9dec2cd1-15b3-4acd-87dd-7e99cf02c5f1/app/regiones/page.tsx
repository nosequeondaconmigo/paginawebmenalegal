import { Card, CardContent } from '@/components/ui/card'
import { Button } from '@/components/ui/button'
import { MapPin, Check, Phone, Video } from 'lucide-react'
import Link from 'next/link'

export const metadata = {
  title: 'Regiones que Atendemos | María de los Ángeles Mena C.',
  description: 'Servicios jurídicos en Región Metropolitana, Región de O\'Higgins y Región de Valparaíso con atención presencial y remota.',
}

export default function Regiones() {
  return (
    <div className="min-h-screen">
      {/* Hero Section */}
      <section className="bg-gradient-to-br from-[#1B3A57] to-[#2A4A67] text-white py-16">
        <div className="container mx-auto px-4">
          <div className="max-w-4xl mx-auto text-center">
            <h1 className="text-4xl md:text-5xl font-serif font-bold mb-4 text-balance">
              Regiones que Atendemos
            </h1>
            <p className="text-xl text-[#F5F1E8]/90 leading-relaxed">
              Servicios jurídicos profesionales en la zona central de Chile
            </p>
          </div>
        </div>
      </section>

      {/* Map Section */}
      <section className="py-16 bg-[#F5F1E8]">
        <div className="container mx-auto px-4">
          <div className="max-w-5xl mx-auto">
            <div className="bg-white rounded-lg p-8 shadow-lg">
              <div className="aspect-video bg-gradient-to-br from-[#1B3A57]/5 to-[#B8935E]/5 rounded-lg flex items-center justify-center mb-6">
                <div className="text-center">
                  <MapPin className="w-16 h-16 text-[#B8935E] mx-auto mb-4" />
                  <p className="text-[#2C2C2C] font-semibold">
                    Mapa de Cobertura: Zona Central de Chile
                  </p>
                  <p className="text-sm text-[#2C2C2C]/60">
                    Región Metropolitana • Región de O'Higgins • Región de Valparaíso
                  </p>
                </div>
              </div>
              <p className="text-center text-[#2C2C2C] leading-relaxed">
                Ofrecemos servicios jurídicos completos en tres regiones estratégicas de Chile, 
                combinando atención presencial de calidad con la flexibilidad de consultas remotas.
              </p>
            </div>
          </div>
        </div>
      </section>

      {/* Regional Details */}
      <section className="py-16 bg-white">
        <div className="container mx-auto px-4">
          <div className="max-w-6xl mx-auto space-y-12">
            {/* Región Metropolitana */}
            <Card className="border-2 border-[#B8935E] shadow-xl">
              <CardContent className="p-8">
                <div className="grid md:grid-cols-2 gap-8">
                  <div>
                    <div className="flex items-center gap-3 mb-4">
                      <div className="w-12 h-12 bg-[#B8935E] rounded-full flex items-center justify-center">
                        <MapPin className="w-6 h-6 text-white" />
                      </div>
                      <h2 className="text-3xl font-serif font-bold text-[#1B3A57]">
                        Región Metropolitana
                      </h2>
                    </div>
                    <p className="text-lg text-[#2C2C2C] leading-relaxed mb-6">
                      Soluciones legales eficientes para el ritmo de Santiago. Asesoría experta y ágil para proteger sus intereses.
                    </p>
                    <div className="space-y-3">
                      <div className="flex items-start gap-2">
                        <Check className="w-5 h-5 text-[#B8935E] mt-1 flex-shrink-0" />
                        <span className="text-[#2C2C2C]">Oficina principal con atención presencial</span>
                      </div>
                      <div className="flex items-start gap-2">
                        <Check className="w-5 h-5 text-[#B8935E] mt-1 flex-shrink-0" />
                        <span className="text-[#2C2C2C]">Reuniones en persona según disponibilidad</span>
                      </div>
                      <div className="flex items-start gap-2">
                        <Check className="w-5 h-5 text-[#B8935E] mt-1 flex-shrink-0" />
                        <span className="text-[#2C2C2C]">Todas las áreas de práctica disponibles</span>
                      </div>
                      <div className="flex items-start gap-2">
                        <Check className="w-5 h-5 text-[#B8935E] mt-1 flex-shrink-0" />
                        <span className="text-[#2C2C2C]">Acompañamiento a tribunales en Santiago</span>
                      </div>
                    </div>
                  </div>
                  <div>
                    <div className="bg-[#F5F1E8] rounded-lg p-6">
                      <h3 className="font-semibold text-[#1B3A57] mb-4">Ventajas de Atención en RM:</h3>
                      <ul className="space-y-2 text-sm text-[#2C2C2C]">
                        <li>• Acceso directo a tribunales metropolitanos</li>
                        <li>• Mayor frecuencia de reuniones presenciales</li>
                        <li>• Respuesta inmediata ante urgencias</li>
                        <li>• Red de contactos en instituciones locales</li>
                      </ul>
                      <div className="mt-6 pt-6 border-t border-[#1B3A57]/10">
                        <div className="flex items-center gap-2 text-sm mb-2">
                          <Phone className="w-4 h-4 text-[#B8935E]" />
                          <span className="font-semibold text-[#1B3A57]">Atención Presencial</span>
                        </div>
                        <div className="flex items-center gap-2 text-sm">
                          <Video className="w-4 h-4 text-[#B8935E]" />
                          <span className="font-semibold text-[#1B3A57]">Consultas Remotas</span>
                        </div>
                      </div>
                    </div>
                  </div>
                </div>
              </CardContent>
            </Card>

            {/* Región de O'Higgins */}
            <Card className="border-2 border-[#1B3A57]/20 shadow-lg">
              <CardContent className="p-8">
                <div className="grid md:grid-cols-2 gap-8">
                  <div>
                    <div className="flex items-center gap-3 mb-4">
                      <div className="w-12 h-12 bg-[#B8935E] rounded-full flex items-center justify-center">
                        <MapPin className="w-6 h-6 text-white" />
                      </div>
                      <h2 className="text-3xl font-serif font-bold text-[#1B3A57]">
                        Región de O'Higgins
                      </h2>
                    </div>
                    <p className="text-lg text-[#2C2C2C] leading-relaxed mb-6">
                      Asesoría legal de confianza en el corazón de O'Higgins. Servicio cercano y profesional.
                    </p>
                    <div className="space-y-3">
                      <div className="flex items-start gap-2">
                        <Check className="w-5 h-5 text-[#B8935E] mt-1 flex-shrink-0" />
                        <span className="text-[#2C2C2C]">Atención remota completa y eficiente</span>
                      </div>
                      <div className="flex items-start gap-2">
                        <Check className="w-5 h-5 text-[#B8935E] mt-1 flex-shrink-0" />
                        <span className="text-[#2C2C2C]">Reuniones presenciales estratégicas</span>
                      </div>
                      <div className="flex items-start gap-2">
                        <Check className="w-5 h-5 text-[#B8935E] mt-1 flex-shrink-0" />
                        <span className="text-[#2C2C2C]">Conocimiento de tribunales locales</span>
                      </div>
                      <div className="flex items-start gap-2">
                        <Check className="w-5 h-5 text-[#B8935E] mt-1 flex-shrink-0" />
                        <span className="text-[#2C2C2C]">Todas las especialidades disponibles</span>
                      </div>
                    </div>
                  </div>
                  <div>
                    <div className="bg-[#F5F1E8] rounded-lg p-6">
                      <h3 className="font-semibold text-[#1B3A57] mb-4">Ventajas de Atención en O'Higgins:</h3>
                      <ul className="space-y-2 text-sm text-[#2C2C2C]">
                        <li>• Flexibilidad de horarios remotos</li>
                        <li>• Ahorro de tiempo y desplazamientos</li>
                        <li>• Comunicación constante vía WhatsApp/email</li>
                        <li>• Reuniones presenciales cuando sean necesarias</li>
                      </ul>
                      <div className="mt-6 pt-6 border-t border-[#1B3A57]/10">
                        <div className="flex items-center gap-2 text-sm mb-2">
                          <Phone className="w-4 h-4 text-[#B8935E]" />
                          <span className="font-semibold text-[#1B3A57]">Presencial Estratégico</span>
                        </div>
                        <div className="flex items-center gap-2 text-sm">
                          <Video className="w-4 h-4 text-[#B8935E]" />
                          <span className="font-semibold text-[#1B3A57]">Remoto Completo</span>
                        </div>
                      </div>
                    </div>
                  </div>
                </div>
              </CardContent>
            </Card>

            {/* Región de Valparaíso */}
            <Card className="border-2 border-[#1B3A57]/20 shadow-lg">
              <CardContent className="p-8">
                <div className="grid md:grid-cols-2 gap-8">
                  <div>
                    <div className="flex items-center gap-3 mb-4">
                      <div className="w-12 h-12 bg-[#B8935E] rounded-full flex items-center justify-center">
                        <MapPin className="w-6 h-6 text-white" />
                      </div>
                      <h2 className="text-3xl font-serif font-bold text-[#1B3A57]">
                        Región de Valparaíso
                      </h2>
                    </div>
                    <p className="text-lg text-[#2C2C2C] leading-relaxed mb-6">
                      Defensa estratégica en Valparaíso. Experiencia para navegar los desafíos legales de la región.
                    </p>
                    <div className="space-y-3">
                      <div className="flex items-start gap-2">
                        <Check className="w-5 h-5 text-[#B8935E] mt-1 flex-shrink-0" />
                        <span className="text-[#2C2C2C]">Servicio remoto integral y profesional</span>
                      </div>
                      <div className="flex items-start gap-2">
                        <Check className="w-5 h-5 text-[#B8935E] mt-1 flex-shrink-0" />
                        <span className="text-[#2C2C2C]">Coordinación de reuniones presenciales</span>
                      </div>
                      <div className="flex items-start gap-2">
                        <Check className="w-5 h-5 text-[#B8935E] mt-1 flex-shrink-0" />
                        <span className="text-[#2C2C2C]">Experiencia en tribunales de la región</span>
                      </div>
                      <div className="flex items-start gap-2">
                        <Check className="w-5 h-5 text-[#B8935E] mt-1 flex-shrink-0" />
                        <span className="text-[#2C2C2C]">Cobertura en todas las áreas legales</span>
                      </div>
                    </div>
                  </div>
                  <div>
                    <div className="bg-[#F5F1E8] rounded-lg p-6">
                      <h3 className="font-semibold text-[#1B3A57] mb-4">Ventajas de Atención en Valparaíso:</h3>
                      <ul className="space-y-2 text-sm text-[#2C2C2C]">
                        <li>• Atención personalizada a distancia</li>
                        <li>• Gestión eficiente de documentación digital</li>
                        <li>• Disponibilidad para casos urgentes</li>
                        <li>• Coordinación presencial según necesidades</li>
                      </ul>
                      <div className="mt-6 pt-6 border-t border-[#1B3A57]/10">
                        <div className="flex items-center gap-2 text-sm mb-2">
                          <Phone className="w-4 h-4 text-[#B8935E]" />
                          <span className="font-semibold text-[#1B3A57]">Presencial Estratégico</span>
                        </div>
                        <div className="flex items-center gap-2 text-sm">
                          <Video className="w-4 h-4 text-[#B8935E]" />
                          <span className="font-semibold text-[#1B3A57]">Remoto Completo</span>
                        </div>
                      </div>
                    </div>
                  </div>
                </div>
              </CardContent>
            </Card>
          </div>
        </div>
      </section>

      {/* CTA */}
      <section className="py-16 bg-[#1B3A57] text-white">
        <div className="container mx-auto px-4">
          <div className="max-w-3xl mx-auto text-center">
            <h2 className="text-3xl md:text-4xl font-serif font-bold mb-6">
              ¿Necesita Asesoría Legal en su Región?
            </h2>
            <p className="text-xl mb-8 text-[#F5F1E8]/90 leading-relaxed">
              Contáctenos hoy para discutir cómo podemos ayudarle, sin importar dónde se encuentre
            </p>
            <Link href="/contacto">
              <Button size="lg" className="bg-[#B8935E] hover:bg-[#A07D4A] text-white font-semibold px-8 py-6 text-lg">
                Agendar Consulta
              </Button>
            </Link>
          </div>
        </div>
      </section>
    </div>
  )
}
