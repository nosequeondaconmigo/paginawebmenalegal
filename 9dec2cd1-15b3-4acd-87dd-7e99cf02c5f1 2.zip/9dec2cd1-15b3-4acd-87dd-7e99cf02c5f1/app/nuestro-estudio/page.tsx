import { Card, CardContent } from '@/components/ui/card'
import { Button } from '@/components/ui/button'
import { Award, BookOpen, Briefcase, GraduationCap, Sparkles } from 'lucide-react'
import Link from 'next/link'

export const metadata = {
  title: 'Nuestro Estudio | María de los Ángeles Mena C.',
  description: 'Conozca a la Licenciada en Derecho María de los Ángeles Mena C., egresada de la Pontificia Universidad Católica de Chile con especialización en Legal Tech e Inteligencia Artificial.',
}

export default function NuestroEstudio() {
  return (
    <div className="min-h-screen">
      {/* Hero Section */}
      <section className="bg-gradient-to-br from-[#1B3A57] to-[#2A4A67] text-white py-16">
        <div className="container mx-auto px-4">
          <div className="max-w-4xl mx-auto text-center">
            <h1 className="text-4xl md:text-5xl font-serif font-bold mb-4 text-balance">
              Nuestro Estudio
            </h1>
            <p className="text-xl text-[#F5F1E8]/90 leading-relaxed">
              Servicios jurídicos profesionales con un enfoque humano y tecnológico
            </p>
          </div>
        </div>
      </section>

      {/* Attorney Profile */}
      <section className="py-16 bg-white">
        <div className="container mx-auto px-4">
          <div className="max-w-5xl mx-auto">
            <div className="grid md:grid-cols-2 gap-12 items-center">
              <div>
                <div className="bg-[#F5F1E8] rounded-lg p-8 aspect-[3/4] flex items-center justify-center">
                  <div className="text-center">
                    <div className="w-32 h-32 bg-[#B8935E] rounded-full mx-auto mb-4 flex items-center justify-center">
                      <span className="text-5xl text-white font-serif">MM</span>
                    </div>
                    <p className="text-sm text-[#2C2C2C]">Fotografía profesional</p>
                  </div>
                </div>
              </div>

              <div>
                <h2 className="text-3xl md:text-4xl font-serif font-bold mb-4 text-[#1B3A57]">
                  María de los Ángeles Mena C.
                </h2>
                <p className="text-lg text-[#B8935E] mb-6 font-semibold">
                  Licenciada en Derecho, Pontificia Universidad Católica de Chile
                </p>
                <div className="prose prose-lg max-w-none text-[#2C2C2C]">
                  <p className="leading-relaxed mb-4">
                    Mi pasión por el derecho nace de la convicción de que la justicia debe ser accesible, comprensible y humana. A lo largo de mi formación en la Pontificia Universidad Católica de Chile, he desarrollado una profunda especialización en áreas críticas que afectan directamente la vida de las personas y familias chilenas.
                  </p>
                  <p className="leading-relaxed mb-4">
                    Creo firmemente en la transparencia y la claridad en los procesos legales. Cada cliente merece entender completamente su situación jurídica y las opciones disponibles. Mi enfoque combina el rigor académico con una atención personalizada y empática.
                  </p>
                  <p className="leading-relaxed">
                    La integración de tecnología y herramientas de inteligencia artificial en mi práctica me permite ofrecer servicios más eficientes sin sacrificar la calidad humana que caracteriza mi trabajo.
                  </p>
                </div>
              </div>
            </div>
          </div>
        </div>
      </section>

      {/* Credentials & Education */}
      <section className="py-16 bg-[#F5F1E8]">
        <div className="container mx-auto px-4">
          <div className="max-w-5xl mx-auto">
            <h2 className="text-3xl md:text-4xl font-serif font-bold mb-12 text-center text-[#1B3A57]">
              Formación y Credenciales
            </h2>

            <div className="space-y-6">
              <Card className="border-none shadow-lg">
                <CardContent className="p-6">
                  <div className="flex items-start gap-4">
                    <div className="w-12 h-12 bg-[#B8935E] rounded-full flex items-center justify-center flex-shrink-0">
                      <GraduationCap className="w-6 h-6 text-white" />
                    </div>
                    <div className="flex-1">
                      <h3 className="text-xl font-serif font-bold mb-2 text-[#1B3A57]">
                        Licenciatura en Derecho
                      </h3>
                      <p className="text-[#B8935E] font-semibold mb-2">
                        Pontificia Universidad Católica de Chile (2018-2025)
                      </p>
                      <p className="text-[#2C2C2C] leading-relaxed">
                        Formación integral en derecho chileno con énfasis en derecho civil, procesal y constitucional. Desarrollo de habilidades de análisis jurídico, argumentación y resolución de casos complejos.
                      </p>
                    </div>
                  </div>
                </CardContent>
              </Card>

              <Card className="border-none shadow-lg">
                <CardContent className="p-6">
                  <div className="flex items-start gap-4">
                    <div className="w-12 h-12 bg-[#B8935E] rounded-full flex items-center justify-center flex-shrink-0">
                      <Award className="w-6 h-6 text-white" />
                    </div>
                    <div className="flex-1">
                      <h3 className="text-xl font-serif font-bold mb-2 text-[#1B3A57]">
                        Certificaciones Internacionales
                      </h3>
                      <ul className="space-y-2 text-[#2C2C2C]">
                        <li className="leading-relaxed">
                          <strong className="text-[#B8935E]">International Water Law</strong> - Conocimientos en regulación internacional
                        </li>
                        <li className="leading-relaxed">
                          <strong className="text-[#B8935E]">Introduction to English Law</strong> - Comprensión del sistema legal anglosajón
                        </li>
                        <li className="leading-relaxed">
                          <strong className="text-[#B8935E]">Introduction to American Law</strong> - Fundamentos del derecho estadounidense
                        </li>
                      </ul>
                    </div>
                  </div>
                </CardContent>
              </Card>

              <Card className="border-none shadow-lg">
                <CardContent className="p-6">
                  <div className="flex items-start gap-4">
                    <div className="w-12 h-12 bg-[#B8935E] rounded-full flex items-center justify-center flex-shrink-0">
                      <Sparkles className="w-6 h-6 text-white" />
                    </div>
                    <div className="flex-1">
                      <h3 className="text-xl font-serif font-bold mb-2 text-[#1B3A57]">
                        Especialización en Legal Tech e Inteligencia Artificial
                      </h3>
                      <p className="text-[#2C2C2C] leading-relaxed mb-3">
                        Formación avanzada en la intersección entre derecho y tecnología, con énfasis en:
                      </p>
                      <ul className="space-y-2 text-[#2C2C2C]">
                        <li>• Ciencia de Datos aplicada al análisis jurídico</li>
                        <li>• Inteligencia Artificial para investigación legal</li>
                        <li>• Herramientas digitales especializadas (OJV, VLex, Zotero, LaTeX)</li>
                        <li>• Colaboración con SPEKTR AI en innovación legal</li>
                      </ul>
                    </div>
                  </div>
                </CardContent>
              </Card>
            </div>
          </div>
        </div>
      </section>

      {/* Publications & Leadership */}
      <section className="py-16 bg-white">
        <div className="container mx-auto px-4">
          <div className="max-w-5xl mx-auto">
            <h2 className="text-3xl md:text-4xl font-serif font-bold mb-12 text-center text-[#1B3A57]">
              Publicaciones y Liderazgo Académico
            </h2>

            <Card className="border-2 border-[#1B3A57]/10">
              <CardContent className="p-8">
                <div className="flex items-start gap-4 mb-6">
                  <div className="w-12 h-12 bg-[#B8935E] rounded-full flex items-center justify-center flex-shrink-0">
                    <BookOpen className="w-6 h-6 text-white" />
                  </div>
                  <div className="flex-1">
                    <h3 className="text-xl font-serif font-bold mb-4 text-[#1B3A57]">
                      Contribuciones Académicas
                    </h3>
                  </div>
                </div>

                <div className="space-y-4">
                  <div className="border-l-4 border-[#B8935E] pl-4 py-2">
                    <h4 className="font-semibold text-[#1B3A57] mb-1">
                      Análisis del Caso Lozapenco
                    </h4>
                    <p className="text-sm text-[#2C2C2C] leading-relaxed">
                      Estudio profundo sobre precedentes judiciales en responsabilidad civil
                    </p>
                  </div>

                  <div className="border-l-4 border-[#B8935E] pl-4 py-2">
                    <h4 className="font-semibold text-[#1B3A57] mb-1">
                      Naturaleza de la Obligación de Indemnizar Perjuicios
                    </h4>
                    <p className="text-sm text-[#2C2C2C] leading-relaxed">
                      Análisis doctrinal sobre fundamentos de la responsabilidad extracontractual
                    </p>
                  </div>

                  <div className="border-l-4 border-[#B8935E] pl-4 py-2">
                    <h4 className="font-semibold text-[#1B3A57] mb-1">
                      Cartas al Director sobre Responsabilidad Extracontractual
                    </h4>
                    <p className="text-sm text-[#2C2C2C] leading-relaxed">
                      Contribuciones al debate público sobre temas de responsabilidad civil
                    </p>
                  </div>
                </div>
              </CardContent>
            </Card>

            <div className="mt-8 grid md:grid-cols-2 gap-6">
              <Card className="border-2 border-[#1B3A57]/10">
                <CardContent className="p-6">
                  <div className="flex items-start gap-3 mb-3">
                    <Briefcase className="w-6 h-6 text-[#B8935E] flex-shrink-0" />
                    <h4 className="font-semibold text-[#1B3A57]">
                      Programa Pasaporte Diplomático
                    </h4>
                  </div>
                  <p className="text-sm text-[#2C2C2C] leading-relaxed">
                    Participación en programa de formación internacional en relaciones diplomáticas y derecho internacional
                  </p>
                </CardContent>
              </Card>

              <Card className="border-2 border-[#1B3A57]/10">
                <CardContent className="p-6">
                  <div className="flex items-start gap-3 mb-3">
                    <Award className="w-6 h-6 text-[#B8935E] flex-shrink-0" />
                    <h4 className="font-semibold text-[#1B3A57]">
                      Centro UC Derecho y Religión
                    </h4>
                  </div>
                  <p className="text-sm text-[#2C2C2C] leading-relaxed">
                    Colaboración en investigación sobre intersecciones entre sistemas normativos legales y religiosos
                  </p>
                </CardContent>
              </Card>
            </div>
          </div>
        </div>
      </section>

      {/* Values */}
      <section className="py-16 bg-[#F5F1E8]">
        <div className="container mx-auto px-4">
          <div className="max-w-5xl mx-auto">
            <h2 className="text-3xl md:text-4xl font-serif font-bold mb-12 text-center text-[#1B3A57]">
              Valores del Estudio
            </h2>

            <div className="grid md:grid-cols-3 gap-6">
              <Card className="border-none shadow-lg bg-white">
                <CardContent className="p-6 text-center">
                  <h3 className="text-xl font-serif font-bold mb-3 text-[#1B3A57]">
                    Transparencia
                  </h3>
                  <p className="text-[#2C2C2C] leading-relaxed">
                    Comunicación clara y honesta sobre procesos, plazos y expectativas en cada caso
                  </p>
                </CardContent>
              </Card>

              <Card className="border-none shadow-lg bg-white">
                <CardContent className="p-6 text-center">
                  <h3 className="text-xl font-serif font-bold mb-3 text-[#1B3A57]">
                    Excelencia
                  </h3>
                  <p className="text-[#2C2C2C] leading-relaxed">
                    Compromiso con la máxima calidad profesional y actualización constante en las áreas de especialización
                  </p>
                </CardContent>
              </Card>

              <Card className="border-none shadow-lg bg-white">
                <CardContent className="p-6 text-center">
                  <h3 className="text-xl font-serif font-bold mb-3 text-[#1B3A57]">
                    Empatía
                  </h3>
                  <p className="text-[#2C2C2C] leading-relaxed">
                    Comprensión profunda de las necesidades y preocupaciones de cada cliente y su familia
                  </p>
                </CardContent>
              </Card>
            </div>
          </div>
        </div>
      </section>

      {/* CTA */}
      <section className="py-16 bg-[#1B3A57] text-white">
        <div className="container mx-auto px-4">
          <div className="max-w-3xl mx-auto text-center">
            <h2 className="text-3xl md:text-4xl font-serif font-bold mb-6">
              Trabaje con una Profesional Certificada
            </h2>
            <p className="text-xl mb-8 text-[#F5F1E8]/90 leading-relaxed">
              Conozca cómo mi formación y experiencia pueden ayudarle a resolver su caso legal
            </p>
            <Link href="/contacto">
              <Button size="lg" className="bg-[#B8935E] hover:bg-[#A07D4A] text-white font-semibold px-8 py-6 text-lg">
                Agendar Consulta
              </Button>
            </Link>
          </div>
        </div>
      </section>
    </div>
  )
}
