import { Card, CardContent } from '@/components/ui/card'
import { Button } from '@/components/ui/button'
import { Star, Quote } from 'lucide-react'
import Link from 'next/link'

export const metadata = {
  title: 'Casos de Éxito | María de los Ángeles Mena C.',
  description: 'Testimonios de clientes satisfechos con nuestros servicios jurídicos en derecho de familia, contratos, negligencias médicas y herencias.',
}

const testimonials = [
  {
    id: 1,
    name: 'María T.',
    region: 'Región Metropolitana',
    area: 'Derecho de Familia',
    rating: 5,
    text: 'Su profesionalismo y empatía hicieron la diferencia en mi caso de divorcio. Me sentí acompañada y bien representada en todo momento. La claridad con la que explicaba cada paso del proceso me dio mucha tranquilidad.',
    highlight: 'Divorcio con custodia compartida'
  },
  {
    id: 2,
    name: 'Carlos R.',
    region: 'Región de O\'Higgins',
    area: 'Contratos Privados',
    rating: 5,
    text: 'Excelente asesoría en la redacción de contratos comerciales. Explicaciones claras y atención detallada. Su conocimiento de la legislación chilena y las mejores prácticas internacionales fue evidente. Totalmente recomendable.',
    highlight: 'Contrato de compraventa comercial'
  },
  {
    id: 3,
    name: 'Patricia L.',
    region: 'Región de Valparaíso',
    area: 'Herencias y Sucesiones',
    rating: 5,
    text: 'Logró defender los derechos de mi familia en un caso complejo de herencia. Su conocimiento y dedicación fueron fundamentales. Nos guió paso a paso en un proceso que parecía imposible de resolver.',
    highlight: 'Liquidación de herencia compleja'
  },
  {
    id: 4,
    name: 'Roberto M.',
    region: 'Región Metropolitana',
    area: 'Negligencias Médicas',
    rating: 5,
    text: 'Después de un error médico que afectó gravemente a mi familia, encontré en ella una abogada que realmente se preocupó por nuestro caso. Su conocimiento técnico y su trato humano fueron excepcionales.',
    highlight: 'Caso de negligencia quirúrgica'
  },
  {
    id: 5,
    name: 'Andrea S.',
    region: 'Región Metropolitana',
    area: 'Derecho de Familia',
    rating: 5,
    text: 'La mejor decisión fue contratarla para mi caso de pensión alimenticia. No solo logró un acuerdo justo, sino que me explicó todos mis derechos y opciones con paciencia. Muy profesional y comprometida.',
    highlight: 'Pensión alimenticia y compensación económica'
  },
  {
    id: 6,
    name: 'Jorge P.',
    region: 'Región de O\'Higgins',
    area: 'Herencias y Sucesiones',
    rating: 5,
    text: 'Necesitaba tramitar la posesión efectiva de mi padre y no sabía por dónde empezar. Su asesoría fue clara, eficiente y muy profesional. Todo el proceso fue mucho más rápido de lo que esperaba.',
    highlight: 'Posesión efectiva y planificación sucesoria'
  },
  {
    id: 7,
    name: 'Francisca G.',
    region: 'Región de Valparaíso',
    area: 'Contratos Privados',
    rating: 5,
    text: 'Me ayudó con la revisión y negociación de un contrato de arrendamiento complejo. Su atención al detalle y capacidad para explicar términos legales complejos en lenguaje simple fue invaluable.',
    highlight: 'Contrato de arrendamiento comercial'
  },
  {
    id: 8,
    name: 'Luis H.',
    region: 'Región Metropolitana',
    area: 'Derecho de Familia',
    rating: 5,
    text: 'Estoy muy agradecido por su trabajo en mi caso de régimen de visitas. Logró un acuerdo que protege el interés superior de mi hijo. Su enfoque equilibrado y su profesionalismo son destacables.',
    highlight: 'Régimen de visitas y cuidado personal'
  },
  {
    id: 9,
    name: 'Valentina C.',
    region: 'Región de O\'Higgins',
    area: 'Negligencias Médicas',
    rating: 5,
    text: 'Después de una mala experiencia médica, ella me ayudó a entender mis derechos y opciones. Su evaluación honesta del caso y su dedicación fueron ejemplares. Recomiendo sus servicios sin dudarlo.',
    highlight: 'Reclamo por diagnóstico erróneo'
  },
]

export default function CasosDeExito() {
  return (
    <div className="min-h-screen">
      {/* Hero Section */}
      <section className="bg-gradient-to-br from-[#1B3A57] to-[#2A4A67] text-white py-16">
        <div className="container mx-auto px-4">
          <div className="max-w-4xl mx-auto text-center">
            <h1 className="text-4xl md:text-5xl font-serif font-bold mb-4 text-balance">
              Casos de Éxito y Testimonios
            </h1>
            <p className="text-xl text-[#F5F1E8]/90 leading-relaxed">
              La satisfacción de nuestros clientes es nuestra mejor carta de presentación
            </p>
          </div>
        </div>
      </section>

      {/* Stats Section */}
      <section className="py-12 bg-[#F5F1E8]">
        <div className="container mx-auto px-4">
          <div className="grid md:grid-cols-4 gap-6 max-w-5xl mx-auto">
            <Card className="border-none shadow-lg bg-white">
              <CardContent className="p-6 text-center">
                <div className="text-4xl font-serif font-bold text-[#B8935E] mb-2">150+</div>
                <p className="text-sm text-[#2C2C2C]">Casos Exitosos</p>
              </CardContent>
            </Card>
            <Card className="border-none shadow-lg bg-white">
              <CardContent className="p-6 text-center">
                <div className="text-4xl font-serif font-bold text-[#B8935E] mb-2">98%</div>
                <p className="text-sm text-[#2C2C2C]">Satisfacción del Cliente</p>
              </CardContent>
            </Card>
            <Card className="border-none shadow-lg bg-white">
              <CardContent className="p-6 text-center">
                <div className="text-4xl font-serif font-bold text-[#B8935E] mb-2">3</div>
                <p className="text-sm text-[#2C2C2C]">Regiones Servidas</p>
              </CardContent>
            </Card>
            <Card className="border-none shadow-lg bg-white">
              <CardContent className="p-6 text-center">
                <div className="text-4xl font-serif font-bold text-[#B8935E] mb-2">24h</div>
                <p className="text-sm text-[#2C2C2C]">Tiempo de Respuesta</p>
              </CardContent>
            </Card>
          </div>
        </div>
      </section>

      {/* Testimonials Grid */}
      <section className="py-16 bg-white">
        <div className="container mx-auto px-4">
          <h2 className="text-3xl md:text-4xl font-serif font-bold text-center mb-12 text-[#1B3A57]">
            Lo que Dicen Nuestros Clientes
          </h2>
          
          <div className="grid md:grid-cols-2 lg:grid-cols-3 gap-6 max-w-7xl mx-auto">
            {testimonials.map((testimonial) => (
              <Card key={testimonial.id} className="border-2 border-[#1B3A57]/10 hover:border-[#B8935E] transition-all hover:shadow-lg">
                <CardContent className="p-6">
                  <div className="flex items-center gap-1 mb-3">
                    {Array.from({ length: testimonial.rating }).map((_, i) => (
                      <Star key={i} className="w-5 h-5 fill-[#B8935E] text-[#B8935E]" />
                    ))}
                  </div>
                  
                  <div className="mb-4">
                    <Quote className="w-8 h-8 text-[#B8935E]/20" />
                  </div>
                  
                  <p className="text-[#2C2C2C] leading-relaxed mb-4 italic">
                    "{testimonial.text}"
                  </p>
                  
                  <div className="pt-4 border-t border-[#1B3A57]/10">
                    <p className="font-semibold text-[#1B3A57] mb-1">{testimonial.name}</p>
                    <p className="text-sm text-[#2C2C2C] mb-1">{testimonial.region}</p>
                    <p className="text-xs text-[#B8935E] font-semibold mb-2">{testimonial.area}</p>
                    <div className="bg-[#F5F1E8] rounded px-2 py-1 inline-block">
                      <p className="text-xs text-[#2C2C2C]">{testimonial.highlight}</p>
                    </div>
                  </div>
                </CardContent>
              </Card>
            ))}
          </div>
        </div>
      </section>

      {/* CTA Section */}
      <section className="py-16 bg-[#1B3A57] text-white">
        <div className="container mx-auto px-4">
          <div className="max-w-3xl mx-auto text-center">
            <h2 className="text-3xl md:text-4xl font-serif font-bold mb-6">
              Su Caso Puede Ser el Próximo Éxito
            </h2>
            <p className="text-xl mb-8 text-[#F5F1E8]/90 leading-relaxed">
              Permítanos ayudarle a resolver su situación legal con el mismo profesionalismo y dedicación
            </p>
            <Link href="/contacto">
              <Button size="lg" className="bg-[#B8935E] hover:bg-[#A07D4A] text-white font-semibold px-8 py-6 text-lg">
                Agendar Consulta Gratuita
              </Button>
            </Link>
          </div>
        </div>
      </section>
    </div>
  )
}
