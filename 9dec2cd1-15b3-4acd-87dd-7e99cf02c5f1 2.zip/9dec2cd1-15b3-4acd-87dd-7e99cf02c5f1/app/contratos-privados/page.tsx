import { Card, CardContent } from '@/components/ui/card'
import { Button } from '@/components/ui/button'
import { Check, FileText, Shield, Users, Building, Briefcase } from 'lucide-react'
import Link from 'next/link'
import ContactSidebar from '@/components/contact-sidebar'
import {
  Accordion,
  AccordionContent,
  AccordionItem,
  AccordionTrigger,
} from "@/components/ui/accordion"
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs"

export const metadata = {
  title: 'Contratos Privados | María de los Ángeles Mena C.',
  description: 'Redacción, revisión y negociación de contratos privados. Contratos comerciales, inmobiliarios, laborales. Servicio en RM, O\'Higgins y Valparaíso.',
}

export default function ContratosPrivados() {
  return (
    <div className="min-h-screen">
      {/* Hero Section */}
      <section className="relative bg-gradient-to-br from-[#1B3A57] via-[#2A4A67] to-[#1B3A57] text-white py-20">
        <div className="container mx-auto px-4">
          <div className="max-w-4xl mx-auto text-center">
            <h1 className="text-4xl md:text-5xl font-serif font-bold mb-6 text-balance">
              Contratos Privados: Proteja sus Intereses Legales
            </h1>
            <p className="text-xl mb-8 text-[#F5F1E8]/90 leading-relaxed">
              Redacción, revisión y negociación de contratos con claridad y precisión jurídica
            </p>
            <Link href="/contacto">
              <Button size="lg" className="bg-[#B8935E] hover:bg-[#A07D4A] text-white font-semibold px-8 py-6 text-lg">
                Asegure Sus Intereses Legales
              </Button>
            </Link>
          </div>
        </div>
      </section>

      <div className="container mx-auto px-4 py-16">
        <div className="grid lg:grid-cols-3 gap-8">
          {/* Main Content */}
          <div className="lg:col-span-2 space-y-12">
            {/* Marco Legal */}
            <section>
              <h2 className="text-3xl font-serif font-bold mb-6 text-[#1B3A57]">
                Marco Legal en Chile
              </h2>
              <Card className="border-2 border-[#1B3A57]/10">
                <CardContent className="p-6">
                  <p className="text-[#2C2C2C] leading-relaxed mb-4">
                    Chile opera bajo un sistema de derecho civil basado en el Código Civil. Los contratos son regidos por el principio de autonomía de la voluntad, pero dentro de marcos normativos específicos.
                  </p>
                  <div className="space-y-3">
                    <div className="flex items-start gap-2">
                      <Check className="w-5 h-5 text-[#B8935E] mt-1 flex-shrink-0" />
                      <p className="text-[#2C2C2C]">
                        <strong>Responsabilidad precontractual:</strong> Las partes deben actuar de buena fe desde las negociaciones
                      </p>
                    </div>
                    <div className="flex items-start gap-2">
                      <Check className="w-5 h-5 text-[#B8935E] mt-1 flex-shrink-0" />
                      <p className="text-[#2C2C2C]">
                        <strong>Daños consecuenciales:</strong> No son reconocidos automáticamente; deben incluirse expresamente
                      </p>
                    </div>
                    <div className="flex items-start gap-2">
                      <Check className="w-5 h-5 text-[#B8935E] mt-1 flex-shrink-0" />
                      <p className="text-[#2C2C2C]">
                        <strong>Ley 20.123:</strong> Responsabilidad subsidiaria por subcontratistas en ciertos sectores
                      </p>
                    </div>
                  </div>
                </CardContent>
              </Card>
            </section>

            {/* Servicios */}
            <section>
              <h2 className="text-3xl font-serif font-bold mb-6 text-[#1B3A57]">
                Servicios Ofrecidos
              </h2>
              <div className="grid md:grid-cols-2 gap-4">
                {[
                  { icon: FileText, title: 'Contratos Comerciales', desc: 'Redacción y revisión especializada' },
                  { icon: Building, title: 'Compraventa Inmobiliaria', desc: 'Escritura pública y due diligence' },
                  { icon: Shield, title: 'Contratos de Arrendamiento', desc: 'Residencial y comercial' },
                  { icon: Users, title: 'Contratos Laborales', desc: 'Plazo fijo e indefinido' },
                  { icon: Briefcase, title: 'Contratos de Construcción', desc: 'Protección integral' },
                  { icon: FileText, title: 'Negociación Contractual', desc: 'Representación estratégica' },
                ].map((servicio, idx) => (
                  <Card key={idx} className="border-2 border-[#1B3A57]/10 hover:border-[#B8935E] transition-colors">
                    <CardContent className="p-4">
                      <div className="flex items-start gap-3">
                        <div className="w-10 h-10 bg-[#B8935E]/10 rounded-full flex items-center justify-center flex-shrink-0">
                          <servicio.icon className="w-5 h-5 text-[#B8935E]" />
                        </div>
                        <div>
                          <h3 className="font-semibold text-[#1B3A57] mb-1">{servicio.title}</h3>
                          <p className="text-sm text-[#2C2C2C]">{servicio.desc}</p>
                        </div>
                      </div>
                    </CardContent>
                  </Card>
                ))}
              </div>
            </section>

            {/* Proceso */}
            <section>
              <h2 className="text-3xl font-serif font-bold mb-6 text-[#1B3A57]">
                Nuestro Proceso
              </h2>
              <div className="space-y-4">
                {[
                  { step: '1', title: 'Consulta Inicial', desc: 'Análisis de necesidades y objetivos contractuales' },
                  { step: '2', title: 'Análisis de Riesgos', desc: 'Identificación de cláusulas críticas y riesgos potenciales' },
                  { step: '3', title: 'Redacción o Revisión', desc: 'Elaboración de borrador contractual o revisión detallada' },
                  { step: '4', title: 'Revisión con Cliente', desc: 'Explicación clara de cada cláusula y sus implicancias' },
                  { step: '5', title: 'Negociación', desc: 'Representación en negociaciones con la contraparte' },
                  { step: '6', title: 'Firma y Formalización', desc: 'Asistencia en firma y registro cuando corresponda' },
                ].map((paso) => (
                  <Card key={paso.step} className="border-l-4 border-[#B8935E]">
                    <CardContent className="p-4">
                      <div className="flex gap-4">
                        <div className="w-10 h-10 bg-[#B8935E] text-white rounded-full flex items-center justify-center font-bold flex-shrink-0">
                          {paso.step}
                        </div>
                        <div className="flex-1">
                          <h3 className="font-semibold text-[#1B3A57] mb-1">{paso.title}</h3>
                          <p className="text-sm text-[#2C2C2C]">{paso.desc}</p>
                        </div>
                      </div>
                    </CardContent>
                  </Card>
                ))}
              </div>
            </section>

            {/* Regional Messaging */}
            <section>
              <h2 className="text-3xl font-serif font-bold mb-6 text-[#1B3A57]">
                Servicio por Región
              </h2>
              <Tabs defaultValue="metropolitana" className="w-full">
                <TabsList className="grid w-full grid-cols-3">
                  <TabsTrigger value="metropolitana">RM</TabsTrigger>
                  <TabsTrigger value="ohiggins">O'Higgins</TabsTrigger>
                  <TabsTrigger value="valparaiso">Valparaíso</TabsTrigger>
                </TabsList>
                <TabsContent value="metropolitana">
                  <Card>
                    <CardContent className="p-6">
                      <h3 className="font-semibold text-[#1B3A57] mb-3">Región Metropolitana</h3>
                      <p className="text-[#2C2C2C] leading-relaxed">
                        Servicios contractuales ágiles y eficientes para el dinámico mercado de Santiago. Atención presencial para negociaciones complejas y representación en operaciones comerciales e inmobiliarias de alto valor.
                      </p>
                    </CardContent>
                  </Card>
                </TabsContent>
                <TabsContent value="ohiggins">
                  <Card>
                    <CardContent className="p-6">
                      <h3 className="font-semibold text-[#1B3A57] mb-3">Región de O'Higgins</h3>
                      <p className="text-[#2C2C2C] leading-relaxed">
                        Asesoría contractual cercana y profesional para empresas y particulares en O'Higgins. Especialización en contratos agrícolas, comerciales y de construcción. Atención remota con reuniones presenciales estratégicas.
                      </p>
                    </CardContent>
                  </Card>
                </TabsContent>
                <TabsContent value="valparaiso">
                  <Card>
                    <CardContent className="p-6">
                      <h3 className="font-semibold text-[#1B3A57] mb-3">Región de Valparaíso</h3>
                      <p className="text-[#2C2C2C] leading-relaxed">
                        Servicios contractuales especializados para el puerto y la zona costera. Experiencia en contratos marítimos, turísticos e inmobiliarios. Cobertura completa con atención remota y presencial según necesidad.
                      </p>
                    </CardContent>
                  </Card>
                </TabsContent>
              </Tabs>
            </section>

            {/* FAQs */}
            <section>
              <h2 className="text-3xl font-serif font-bold mb-6 text-[#1B3A57]">
                Preguntas Frecuentes
              </h2>
              <Accordion type="single" collapsible className="w-full">
                <AccordionItem value="item-1">
                  <AccordionTrigger className="text-left">
                    ¿Cuánto tiempo toma redactar un contrato?
                  </AccordionTrigger>
                  <AccordionContent>
                    <p className="text-[#2C2C2C] leading-relaxed">
                      Depende de la complejidad. Un contrato estándar puede estar listo en 3-5 días hábiles. Contratos complejos o con múltiples partes pueden tomar 1-2 semanas.
                    </p>
                  </AccordionContent>
                </AccordionItem>
                <AccordionItem value="item-2">
                  <AccordionTrigger className="text-left">
                    ¿Es necesario firmar ante notario?
                  </AccordionTrigger>
                  <AccordionContent>
                    <p className="text-[#2C2C2C] leading-relaxed">
                      Algunos contratos requieren escritura pública (compraventa inmobiliaria, constitución de sociedades). Otros pueden ser privados, pero la firma ante notario añade seguridad jurídica.
                    </p>
                  </AccordionContent>
                </AccordionItem>
                <AccordionItem value="item-3">
                  <AccordionTrigger className="text-left">
                    ¿Qué sucede si la otra parte incumple el contrato?
                  </AccordionTrigger>
                  <AccordionContent>
                    <p className="text-[#2C2C2C] leading-relaxed">
                      Existen remedios legales: cumplimiento forzado, resolución del contrato, indemnización de perjuicios. La mejor estrategia depende del tipo de incumplimiento y las cláusulas contractuales.
                    </p>
                  </AccordionContent>
                </AccordionItem>
                <AccordionItem value="item-4">
                  <AccordionTrigger className="text-left">
                    ¿Puedo modificar un contrato ya firmado?
                  </AccordionTrigger>
                  <AccordionContent>
                    <p className="text-[#2C2C2C] leading-relaxed">
                      Sí, mediante un anexo o modificación contractual firmada por todas las partes. Es fundamental documentar correctamente cualquier cambio para evitar disputas futuras.
                    </p>
                  </AccordionContent>
                </AccordionItem>
                <AccordionItem value="item-5">
                  <AccordionTrigger className="text-left">
                    ¿Qué cláusulas son más importantes en un contrato?
                  </AccordionTrigger>
                  <AccordionContent>
                    <p className="text-[#2C2C2C] leading-relaxed">
                      Cláusulas de objeto y precio, plazo, condiciones de pago, causales de terminación, responsabilidades, resolución de controversias, y jurisdicción. Cada contrato tiene particularidades que requieren análisis específico.
                    </p>
                  </AccordionContent>
                </AccordionItem>
              </Accordion>
            </section>

            {/* CTA */}
            <Card className="border-2 border-[#B8935E] bg-[#F5F1E8]">
              <CardContent className="p-8 text-center">
                <h3 className="text-2xl font-serif font-bold mb-4 text-[#1B3A57]">
                  ¿Necesita Redactar o Revisar un Contrato?
                </h3>
                <p className="text-[#2C2C2C] mb-6 leading-relaxed">
                  Proteja sus intereses con asesoría legal especializada
                </p>
                <Link href="/contacto">
                  <Button size="lg" className="bg-[#B8935E] hover:bg-[#A07D4A] text-white font-semibold">
                    Solicitar Consulta
                  </Button>
                </Link>
              </CardContent>
            </Card>
          </div>

          {/* Sidebar */}
          <div className="lg:col-span-1">
            <ContactSidebar />
          </div>
        </div>
      </div>
    </div>
  )
}
