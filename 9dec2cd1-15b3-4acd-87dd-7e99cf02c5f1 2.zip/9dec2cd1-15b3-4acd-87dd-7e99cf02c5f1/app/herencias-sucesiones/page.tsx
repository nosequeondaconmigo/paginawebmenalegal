import { Card, CardContent } from '@/components/ui/card'
import { Button } from '@/components/ui/button'
import { Check, FileText, Users, Scale, Shield, Briefcase } from 'lucide-react'
import Link from 'next/link'
import ContactSidebar from '@/components/contact-sidebar'
import {
  Accordion,
  AccordionContent,
  AccordionItem,
  AccordionTrigger,
} from "@/components/ui/accordion"
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs"

export const metadata = {
  title: 'Herencias y Sucesiones | María de los Ángeles Mena C.',
  description: 'Testamentos, posesión efectiva, planificación sucesoria. Asesoría especializada en herencias. Servicio en RM, O\'Higgins y Valparaíso.',
}

export default function HerenciasSucesiones() {
  return (
    <div className="min-h-screen">
      {/* Hero Section */}
      <section className="relative bg-gradient-to-br from-[#1B3A57] via-[#2A4A67] to-[#1B3A57] text-white py-20">
        <div className="container mx-auto px-4">
          <div className="max-w-4xl mx-auto text-center">
            <h1 className="text-4xl md:text-5xl font-serif font-bold mb-6 text-balance">
              Herencias y Sucesiones: Planifique Su Patrimonio con Seguridad
            </h1>
            <p className="text-xl mb-8 text-[#F5F1E8]/90 leading-relaxed">
              Asesoría especializada en planificación sucesoria, testamentos y tramitación de herencias
            </p>
            <Link href="/contacto">
              <Button size="lg" className="bg-[#B8935E] hover:bg-[#A07D4A] text-white font-semibold px-8 py-6 text-lg">
                Proteger Mi Patrimonio
              </Button>
            </Link>
          </div>
        </div>
      </section>

      <div className="container mx-auto px-4 py-16">
        <div className="grid lg:grid-cols-3 gap-8">
          {/* Main Content */}
          <div className="lg:col-span-2 space-y-12">
            {/* Marco Legal */}
            <section>
              <h2 className="text-3xl font-serif font-bold mb-6 text-[#1B3A57]">
                Marco Legal en Chile
              </h2>
              <Card className="border-2 border-[#1B3A57]/10">
                <CardContent className="p-6">
                  <p className="text-[#2C2C2C] leading-relaxed mb-4">
                    El sistema sucesorio chileno se caracteriza por un régimen de <strong>legítimas rigurosas</strong> que limita la libertad testamentaria:
                  </p>
                  <div className="space-y-4">
                    <div className="grid md:grid-cols-3 gap-4 mb-4">
                      <Card className="border-2 border-[#B8935E]">
                        <CardContent className="p-4 text-center">
                          <p className="text-3xl font-bold text-[#B8935E] mb-1">50%</p>
                          <p className="text-sm text-[#1B3A57] font-semibold">Legitimarios</p>
                          <p className="text-xs text-[#2C2C2C]">Hijos y descendientes</p>
                        </CardContent>
                      </Card>
                      <Card className="border-2 border-[#B8935E]">
                        <CardContent className="p-4 text-center">
                          <p className="text-3xl font-bold text-[#B8935E] mb-1">25%</p>
                          <p className="text-sm text-[#1B3A57] font-semibold">Mejoras</p>
                          <p className="text-xs text-[#2C2C2C]">Descendientes o cónyuge</p>
                        </CardContent>
                      </Card>
                      <Card className="border-2 border-[#B8935E]">
                        <CardContent className="p-4 text-center">
                          <p className="text-3xl font-bold text-[#B8935E] mb-1">25%</p>
                          <p className="text-sm text-[#1B3A57] font-semibold">Libre Disposición</p>
                          <p className="text-xs text-[#2C2C2C]">Sin restricciones</p>
                        </CardContent>
                      </Card>
                    </div>
                    <div className="space-y-2">
                      <div className="flex items-start gap-2">
                        <Check className="w-5 h-5 text-[#B8935E] mt-1 flex-shrink-0" />
                        <p className="text-[#2C2C2C]">
                          <strong>Posesión efectiva:</strong> Trámite obligatorio ante Servicio de Registro Civil (vía administrativa) o tribunales (vía judicial)
                        </p>
                      </div>
                      <div className="flex items-start gap-2">
                        <Check className="w-5 h-5 text-[#B8935E] mt-1 flex-shrink-0" />
                        <p className="text-[#2C2C2C]">
                          <strong>Impuesto a la herencia:</strong> Tasa progresiva según monto y parentesco (exentos hasta aproximadamente $71 millones para hijos)
                        </p>
                      </div>
                    </div>
                  </div>
                </CardContent>
              </Card>
            </section>

            {/* Servicios */}
            <section>
              <h2 className="text-3xl font-serif font-bold mb-6 text-[#1B3A57]">
                Servicios Ofrecidos
              </h2>
              <div className="grid md:grid-cols-2 gap-4">
                {[
                  { icon: FileText, title: 'Redacción de Testamentos', desc: 'Abiertos y cerrados ante notario' },
                  { icon: Scale, title: 'Tramitación Posesión Efectiva', desc: 'Administrativa y judicial' },
                  { icon: Users, title: 'Liquidación de Herencia', desc: 'Partición y distribución de bienes' },
                  { icon: Briefcase, title: 'Planificación Sucesoria', desc: 'Estrategias de protección patrimonial' },
                  { icon: FileText, title: 'Impuesto a la Herencia', desc: 'Cálculo y optimización tributaria' },
                  { icon: Shield, title: 'Donaciones', desc: 'Asesoría en donaciones entre vivos' },
                ].map((servicio, idx) => (
                  <Card key={idx} className="border-2 border-[#1B3A57]/10 hover:border-[#B8935E] transition-colors">
                    <CardContent className="p-4">
                      <div className="flex items-start gap-3">
                        <div className="w-10 h-10 bg-[#B8935E]/10 rounded-full flex items-center justify-center flex-shrink-0">
                          <servicio.icon className="w-5 h-5 text-[#B8935E]" />
                        </div>
                        <div>
                          <h3 className="font-semibold text-[#1B3A57] mb-1">{servicio.title}</h3>
                          <p className="text-sm text-[#2C2C2C]">{servicio.desc}</p>
                        </div>
                      </div>
                    </CardContent>
                  </Card>
                ))}
              </div>
            </section>

            {/* Proceso Posesión Efectiva */}
            <section>
              <h2 className="text-3xl font-serif font-bold mb-6 text-[#1B3A57]">
                Proceso de Posesión Efectiva
              </h2>
              <Tabs defaultValue="administrativa" className="w-full mb-6">
                <TabsList className="grid w-full grid-cols-2">
                  <TabsTrigger value="administrativa">Vía Administrativa</TabsTrigger>
                  <TabsTrigger value="judicial">Vía Judicial</TabsTrigger>
                </TabsList>
                <TabsContent value="administrativa">
                  <Card>
                    <CardContent className="p-6">
                      <p className="text-[#2C2C2C] mb-4 leading-relaxed">
                        <strong>Aplicable cuando:</strong> Todos los herederos son mayores de edad, no hay conflictos, y existe testamento válido o sucesión intestada clara.
                      </p>
                      <div className="space-y-3">
                        {[
                          { paso: '1', titulo: 'Recopilación de Documentos', detalle: 'Certificado defunción, testamento (si existe), certificados de nacimiento y matrimonio' },
                          { paso: '2', titulo: 'Solicitud ante Registro Civil', detalle: 'Presentación de antecedentes y formularios' },
                          { paso: '3', titulo: 'Publicación en Diario Oficial', detalle: 'Aviso legal obligatorio' },
                          { paso: '4', titulo: 'Resolución', detalle: 'Emisión de resolución de posesión efectiva (30-60 días)' },
                          { paso: '5', titulo: 'Inscripción en CBR', detalle: 'Registro de bienes inmuebles' },
                        ].map((paso) => (
                          <div key={paso.paso} className="flex gap-3 items-start">
                            <div className="w-8 h-8 bg-[#B8935E] text-white rounded-full flex items-center justify-center text-sm font-bold flex-shrink-0">
                              {paso.paso}
                            </div>
                            <div>
                              <p className="font-semibold text-[#1B3A57]">{paso.titulo}</p>
                              <p className="text-sm text-[#2C2C2C]">{paso.detalle}</p>
                            </div>
                          </div>
                        ))}
                      </div>
                    </CardContent>
                  </Card>
                </TabsContent>
                <TabsContent value="judicial">
                  <Card>
                    <CardContent className="p-6">
                      <p className="text-[#2C2C2C] mb-4 leading-relaxed">
                        <strong>Requerida cuando:</strong> Hay menores de edad, herederos desconocidos, testamentos impugnados, o conflictos entre herederos.
                      </p>
                      <div className="space-y-3">
                        {[
                          { paso: '1', titulo: 'Demanda Judicial', detalle: 'Presentación ante tribunal civil' },
                          { paso: '2', titulo: 'Notificación', detalle: 'A todos los herederos conocidos' },
                          { paso: '3', titulo: 'Publicación Edictos', detalle: 'Para herederos desconocidos' },
                          { paso: '4', titulo: 'Tramitación', detalle: 'Audiencias y resolución de controversias' },
                          { paso: '5', titulo: 'Sentencia', detalle: 'Declaración judicial de herederos (6-18 meses)' },
                        ].map((paso) => (
                          <div key={paso.paso} className="flex gap-3 items-start">
                            <div className="w-8 h-8 bg-[#B8935E] text-white rounded-full flex items-center justify-center text-sm font-bold flex-shrink-0">
                              {paso.paso}
                            </div>
                            <div>
                              <p className="font-semibold text-[#1B3A57]">{paso.titulo}</p>
                              <p className="text-sm text-[#2C2C2C]">{paso.detalle}</p>
                            </div>
                          </div>
                        ))}
                      </div>
                    </CardContent>
                  </Card>
                </TabsContent>
              </Tabs>
            </section>

            {/* Planificación Sucesoria */}
            <section>
              <h2 className="text-3xl font-serif font-bold mb-6 text-[#1B3A57]">
                Planificación Sucesoria Estratégica
              </h2>
              <Card className="border-2 border-[#B8935E] bg-[#F5F1E8]">
                <CardContent className="p-6">
                  <p className="text-[#2C2C2C] mb-4 leading-relaxed">
                    Una planificación sucesoria adecuada le permite proteger su patrimonio, minimizar impuestos y evitar conflictos familiares. Nuestros servicios incluyen:
                  </p>
                  <div className="space-y-3">
                    {[
                      'Análisis patrimonial y familiar completo',
                      'Estrategias de optimización del impuesto a la herencia',
                      'Estructuración mediante sociedades y holdings familiares',
                      'Donaciones estratégicas en vida',
                      'Seguros de vida como herramienta sucesoria',
                      'Testamentos con cláusulas especiales de protección',
                    ].map((item, idx) => (
                      <div key={idx} className="flex items-start gap-2">
                        <Check className="w-5 h-5 text-[#B8935E] mt-0.5 flex-shrink-0" />
                        <p className="text-[#2C2C2C]">{item}</p>
                      </div>
                    ))}
                  </div>
                </CardContent>
              </Card>
            </section>

            {/* Regional Messaging */}
            <section>
              <h2 className="text-3xl font-serif font-bold mb-6 text-[#1B3A57]">
                Servicio por Región
              </h2>
              <Tabs defaultValue="metropolitana" className="w-full">
                <TabsList className="grid w-full grid-cols-3">
                  <TabsTrigger value="metropolitana">RM</TabsTrigger>
                  <TabsTrigger value="ohiggins">O'Higgins</TabsTrigger>
                  <TabsTrigger value="valparaiso">Valparaíso</TabsTrigger>
                </TabsList>
                <TabsContent value="metropolitana">
                  <Card>
                    <CardContent className="p-6">
                      <h3 className="font-semibold text-[#1B3A57] mb-3">Región Metropolitana</h3>
                      <p className="text-[#2C2C2C] leading-relaxed">
                        Servicios completos de planificación sucesoria y tramitación de herencias en Santiago. Coordinación eficiente con Registro Civil, Conservador de Bienes Raíces y SII. Atención presencial para casos complejos de alto patrimonio.
                      </p>
                    </CardContent>
                  </Card>
                </TabsContent>
                <TabsContent value="ohiggins">
                  <Card>
                    <CardContent className="p-6">
                      <h3 className="font-semibold text-[#1B3A57] mb-3">Región de O'Higgins</h3>
                      <p className="text-[#2C2C2C] leading-relaxed">
                        Asesoría sucesoria especializada para familias de O'Higgins. Experiencia en herencias con componente agrícola y rural. Tramitación eficiente ante organismos locales con atención personalizada.
                      </p>
                    </CardContent>
                  </Card>
                </TabsContent>
                <TabsContent value="valparaiso">
                  <Card>
                    <CardContent className="p-6">
                      <h3 className="font-semibold text-[#1B3A57] mb-3">Región de Valparaíso</h3>
                      <p className="text-[#2C2C2C] leading-relaxed">
                        Servicios integrales de herencias y sucesiones en Valparaíso. Coordinación con tribunales y conservadores de la región. Especialización en patrimonios inmobiliarios costeros y urbanos.
                      </p>
                    </CardContent>
                  </Card>
                </TabsContent>
              </Tabs>
            </section>

            {/* FAQs */}
            <section>
              <h2 className="text-3xl font-serif font-bold mb-6 text-[#1B3A57]">
                Preguntas Frecuentes
              </h2>
              <Accordion type="single" collapsible className="w-full">
                <AccordionItem value="item-1">
                  <AccordionTrigger className="text-left">
                    ¿Es obligatorio hacer testamento?
                  </AccordionTrigger>
                  <AccordionContent>
                    <p className="text-[#2C2C2C] leading-relaxed">
                      No es obligatorio. Si no hay testamento, opera la sucesión intestada según el orden legal. Sin embargo, un testamento permite distribuir el 25% de libre disposición y designar albacea, entre otros beneficios.
                    </p>
                  </AccordionContent>
                </AccordionItem>
                <AccordionItem value="item-2">
                  <AccordionTrigger className="text-left">
                    ¿Cuánto tiempo toma tramitar una posesión efectiva?
                  </AccordionTrigger>
                  <AccordionContent>
                    <p className="text-[#2C2C2C] leading-relaxed">
                      Vía administrativa: 2-4 meses típicamente. Vía judicial: 6-18 meses dependiendo de la complejidad. Los plazos pueden extenderse si hay controversias o documentación incompleta.
                    </p>
                  </AccordionContent>
                </AccordionItem>
                <AccordionItem value="item-3">
                  <AccordionTrigger className="text-left">
                    ¿Puedo desheredar a un hijo?
                  </AccordionTrigger>
                  <AccordionContent>
                    <p className="text-[#2C2C2C] leading-relaxed">
                      Solo por causales específicas y graves contempladas en la ley (injuria atroz, abandono al causante, condena por ciertos delitos). La desheredación debe constar en testamento y puede ser impugnada judicialmente.
                    </p>
                  </AccordionContent>
                </AccordionItem>
                <AccordionItem value="item-4">
                  <AccordionTrigger className="text-left">
                    ¿Cómo se calcula el impuesto a la herencia?
                  </AccordionTrigger>
                  <AccordionContent>
                    <p className="text-[#2C2C2C] leading-relaxed">
                      Depende del monto heredado y del parentesco. Los hijos tienen una exención de aproximadamente 50 UTA (cerca de $35 millones). Sobre el exceso se aplica una tasa progresiva del 1% al 25%. Cónyuge tiene exención mayor.
                    </p>
                  </AccordionContent>
                </AccordionItem>
                <AccordionItem value="item-5">
                  <AccordionTrigger className="text-left">
                    ¿Qué pasa si hay deudas del fallecido?
                  </AccordionTrigger>
                  <AccordionContent>
                    <p className="text-[#2C2C2C] leading-relaxed">
                      Los herederos responden de las deudas solo hasta el monto de lo heredado, si aceptan la herencia con beneficio de inventario. Es crucial evaluar el activo y pasivo de la herencia antes de aceptarla.
                    </p>
                  </AccordionContent>
                </AccordionItem>
              </Accordion>
            </section>

            {/* CTA */}
            <Card className="border-2 border-[#B8935E] bg-[#F5F1E8]">
              <CardContent className="p-8 text-center">
                <h3 className="text-2xl font-serif font-bold mb-4 text-[#1B3A57]">
                  ¿Necesita Planificar Su Sucesión o Tramitar una Herencia?
                </h3>
                <p className="text-[#2C2C2C] mb-6 leading-relaxed">
                  Proteja su patrimonio familiar con asesoría legal especializada
                </p>
                <Link href="/contacto">
                  <Button size="lg" className="bg-[#B8935E] hover:bg-[#A07D4A] text-white font-semibold">
                    Agendar Consulta
                  </Button>
                </Link>
              </CardContent>
            </Card>
          </div>

          {/* Sidebar */}
          <div className="lg:col-span-1">
            <ContactSidebar />
          </div>
        </div>
      </div>
    </div>
  )
}
