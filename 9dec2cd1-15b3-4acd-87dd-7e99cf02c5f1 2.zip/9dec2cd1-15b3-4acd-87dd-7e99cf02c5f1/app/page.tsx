import Link from 'next/link'
import { Button } from '@/components/ui/button'
import { Card, CardContent } from '@/components/ui/card'
import { Phone, Mail, MapPin, Scale, Users, Award, MessageCircle, Check } from 'lucide-react'
import Image from 'next/image'

export default function Home() {
  return (
    <div className="min-h-screen">
      {/* Hero Section */}
      <section className="relative bg-gradient-to-br from-[#1B3A57] via-[#2A4A67] to-[#1B3A57] text-white py-24 md:py-32">
        <div className="absolute inset-0 bg-[url('/hero-pattern.svg')] opacity-5"></div>
        <div className="container mx-auto px-4 relative z-10">
          <div className="max-w-4xl mx-auto text-center">
            <h1 className="text-4xl md:text-6xl font-serif font-bold mb-6 text-balance">
              Asesoría Legal Especializada en la Zona Central de Chile
            </h1>
            <p className="text-xl md:text-2xl mb-4 text-[#F5F1E8]/90">
              Servicios jurídicos profesionales en Región Metropolitana, Región de O'Higgins y Región de Valparaíso
            </p>
            <p className="text-lg mb-8 text-[#F5F1E8]/80">
              Especialización en Derecho de Familia, Contratos Privados, Negligencias Médicas y Herencias
            </p>
            <div className="flex flex-col sm:flex-row gap-4 justify-center">
              <Link href="#consulta">
                <Button size="lg" className="bg-[#B8935E] hover:bg-[#A07D4A] text-white font-semibold px-8 py-6 text-lg w-full sm:w-auto">
                  Agende Su Consulta Gratuita
                </Button>
              </Link>
              <Link href="/contacto">
                <Button size="lg" variant="outline" className="border-2 border-white text-white hover:bg-white hover:text-[#1B3A57] font-semibold px-8 py-6 text-lg w-full sm:w-auto bg-transparent">
                  Conozca Nuestros Servicios
                </Button>
              </Link>
            </div>
          </div>
        </div>
      </section>

      {/* Value Proposition */}
      <section className="py-16 bg-[#F5F1E8]">
        <div className="container mx-auto px-4">
          <h2 className="text-3xl md:text-4xl font-serif font-bold text-center mb-12 text-[#1B3A57]">
            Por Qué Elegirnos
          </h2>
          <div className="grid md:grid-cols-3 gap-8">
            <Card className="border-none shadow-lg hover:shadow-xl transition-shadow bg-white">
              <CardContent className="p-8 text-center">
                <div className="w-16 h-16 bg-[#B8935E]/10 rounded-full flex items-center justify-center mx-auto mb-6">
                  <Scale className="w-8 h-8 text-[#B8935E]" />
                </div>
                <h3 className="text-xl font-serif font-bold mb-4 text-[#1B3A57]">
                  Claridad y Transparencia en Procesos Complejos
                </h3>
                <p className="text-[#2C2C2C] leading-relaxed">
                  Transformamos la complejidad legal en explicaciones claras y comprensibles, guiándole paso a paso en cada etapa de su caso.
                </p>
              </CardContent>
            </Card>

            <Card className="border-none shadow-lg hover:shadow-xl transition-shadow bg-white">
              <CardContent className="p-8 text-center">
                <div className="w-16 h-16 bg-[#B8935E]/10 rounded-full flex items-center justify-center mx-auto mb-6">
                  <Award className="w-8 h-8 text-[#B8935E]" />
                </div>
                <h3 className="text-xl font-serif font-bold mb-4 text-[#1B3A57]">
                  Alta Especialización en Áreas Críticas
                </h3>
                <p className="text-[#2C2C2C] leading-relaxed">
                  Formación académica en Pontificia Universidad Católica de Chile y especialización en Legal Tech e Inteligencia Artificial aplicada al derecho.
                </p>
              </CardContent>
            </Card>

            <Card className="border-none shadow-lg hover:shadow-xl transition-shadow bg-white">
              <CardContent className="p-8 text-center">
                <div className="w-16 h-16 bg-[#B8935E]/10 rounded-full flex items-center justify-center mx-auto mb-6">
                  <Users className="w-8 h-8 text-[#B8935E]" />
                </div>
                <h3 className="text-xl font-serif font-bold mb-4 text-[#1B3A57]">
                  Representación con Calidad Humana
                </h3>
                <p className="text-[#2C2C2C] leading-relaxed">
                  Comprendemos que detrás de cada caso hay personas y familias. Ofrecemos atención personalizada, empática y profesional.
                </p>
              </CardContent>
            </Card>
          </div>
        </div>
      </section>

      {/* Practice Areas */}
      <section className="py-16 bg-white">
        <div className="container mx-auto px-4">
          <h2 className="text-3xl md:text-4xl font-serif font-bold text-center mb-4 text-[#1B3A57]">
            Áreas de Práctica
          </h2>
          <p className="text-center text-[#2C2C2C] mb-12 max-w-2xl mx-auto leading-relaxed">
            Servicios jurídicos especializados para proteger sus derechos e intereses
          </p>
          
          <div className="grid md:grid-cols-2 gap-6 max-w-5xl mx-auto">
            <Link href="/derecho-de-familia">
              <Card className="border-2 border-[#1B3A57]/10 hover:border-[#B8935E] hover:shadow-lg transition-all cursor-pointer h-full">
                <CardContent className="p-6">
                  <h3 className="text-2xl font-serif font-bold mb-3 text-[#1B3A57]">Derecho de Familia</h3>
                  <ul className="space-y-2 text-[#2C2C2C]">
                    <li className="flex items-start gap-2">
                      <Check className="w-5 h-5 text-[#B8935E] mt-0.5 flex-shrink-0" />
                      <span>Divorcio (mutuo acuerdo y unilateral)</span>
                    </li>
                    <li className="flex items-start gap-2">
                      <Check className="w-5 h-5 text-[#B8935E] mt-0.5 flex-shrink-0" />
                      <span>Cuidado personal y régimen de visitas</span>
                    </li>
                    <li className="flex items-start gap-2">
                      <Check className="w-5 h-5 text-[#B8935E] mt-0.5 flex-shrink-0" />
                      <span>Pensión alimenticia y compensación económica</span>
                    </li>
                    <li className="flex items-start gap-2">
                      <Check className="w-5 h-5 text-[#B8935E] mt-0.5 flex-shrink-0" />
                      <span>Liquidación sociedad conyugal</span>
                    </li>
                  </ul>
                  <Button className="mt-6 bg-[#B8935E] hover:bg-[#A07D4A] w-full">
                    Ver Más Información
                  </Button>
                </CardContent>
              </Card>
            </Link>

            <Link href="/contratos-privados">
              <Card className="border-2 border-[#1B3A57]/10 hover:border-[#B8935E] hover:shadow-lg transition-all cursor-pointer h-full">
                <CardContent className="p-6">
                  <h3 className="text-2xl font-serif font-bold mb-3 text-[#1B3A57]">Contratos Privados</h3>
                  <ul className="space-y-2 text-[#2C2C2C]">
                    <li className="flex items-start gap-2">
                      <Check className="w-5 h-5 text-[#B8935E] mt-0.5 flex-shrink-0" />
                      <span>Redacción y revisión de contratos comerciales</span>
                    </li>
                    <li className="flex items-start gap-2">
                      <Check className="w-5 h-5 text-[#B8935E] mt-0.5 flex-shrink-0" />
                      <span>Contratos de compraventa inmobiliaria</span>
                    </li>
                    <li className="flex items-start gap-2">
                      <Check className="w-5 h-5 text-[#B8935E] mt-0.5 flex-shrink-0" />
                      <span>Contratos de arrendamiento y laborales</span>
                    </li>
                    <li className="flex items-start gap-2">
                      <Check className="w-5 h-5 text-[#B8935E] mt-0.5 flex-shrink-0" />
                      <span>Negociación y resolución de controversias</span>
                    </li>
                  </ul>
                  <Button className="mt-6 bg-[#B8935E] hover:bg-[#A07D4A] w-full">
                    Ver Más Información
                  </Button>
                </CardContent>
              </Card>
            </Link>

            <Link href="/negligencias-medicas">
              <Card className="border-2 border-[#1B3A57]/10 hover:border-[#B8935E] hover:shadow-lg transition-all cursor-pointer h-full">
                <CardContent className="p-6">
                  <h3 className="text-2xl font-serif font-bold mb-3 text-[#1B3A57]">Negligencias Médicas</h3>
                  <ul className="space-y-2 text-[#2C2C2C]">
                    <li className="flex items-start gap-2">
                      <Check className="w-5 h-5 text-[#B8935E] mt-0.5 flex-shrink-0" />
                      <span>Evaluación de viabilidad del caso</span>
                    </li>
                    <li className="flex items-start gap-2">
                      <Check className="w-5 h-5 text-[#B8935E] mt-0.5 flex-shrink-0" />
                      <span>Reclamos ante establecimientos de salud</span>
                    </li>
                    <li className="flex items-start gap-2">
                      <Check className="w-5 h-5 text-[#B8935E] mt-0.5 flex-shrink-0" />
                      <span>Mediación y demanda judicial por daños</span>
                    </li>
                    <li className="flex items-start gap-2">
                      <Check className="w-5 h-5 text-[#B8935E] mt-0.5 flex-shrink-0" />
                      <span>Defensa de derechos como paciente</span>
                    </li>
                  </ul>
                  <Button className="mt-6 bg-[#B8935E] hover:bg-[#A07D4A] w-full">
                    Ver Más Información
                  </Button>
                </CardContent>
              </Card>
            </Link>

            <Link href="/herencias-sucesiones">
              <Card className="border-2 border-[#1B3A57]/10 hover:border-[#B8935E] hover:shadow-lg transition-all cursor-pointer h-full">
                <CardContent className="p-6">
                  <h3 className="text-2xl font-serif font-bold mb-3 text-[#1B3A57]">Herencias y Sucesiones</h3>
                  <ul className="space-y-2 text-[#2C2C2C]">
                    <li className="flex items-start gap-2">
                      <Check className="w-5 h-5 text-[#B8935E] mt-0.5 flex-shrink-0" />
                      <span>Redacción de testamentos</span>
                    </li>
                    <li className="flex items-start gap-2">
                      <Check className="w-5 h-5 text-[#B8935E] mt-0.5 flex-shrink-0" />
                      <span>Tramitación posesión efectiva</span>
                    </li>
                    <li className="flex items-start gap-2">
                      <Check className="w-5 h-5 text-[#B8935E] mt-0.5 flex-shrink-0" />
                      <span>Liquidación y planificación sucesoria</span>
                    </li>
                    <li className="flex items-start gap-2">
                      <Check className="w-5 h-5 text-[#B8935E] mt-0.5 flex-shrink-0" />
                      <span>Asesoría sobre impuesto a la herencia</span>
                    </li>
                  </ul>
                  <Button className="mt-6 bg-[#B8935E] hover:bg-[#A07D4A] w-full">
                    Ver Más Información
                  </Button>
                </CardContent>
              </Card>
            </Link>
          </div>
        </div>
      </section>

      {/* Regional Coverage */}
      <section className="py-16 bg-[#F5F1E8]">
        <div className="container mx-auto px-4">
          <h2 className="text-3xl md:text-4xl font-serif font-bold text-center mb-4 text-[#1B3A57]">
            Regiones que Atendemos
          </h2>
          <p className="text-center text-[#2C2C2C] mb-12 max-w-2xl mx-auto leading-relaxed">
            Servicios jurídicos profesionales en la zona central de Chile con atención presencial y remota
          </p>

          <div className="grid md:grid-cols-3 gap-6 max-w-5xl mx-auto">
            <Card className="border-none shadow-lg bg-white">
              <CardContent className="p-6">
                <div className="w-12 h-12 bg-[#B8935E] rounded-full flex items-center justify-center mb-4">
                  <MapPin className="w-6 h-6 text-white" />
                </div>
                <h3 className="text-xl font-serif font-bold mb-3 text-[#1B3A57]">Región Metropolitana</h3>
                <p className="text-[#2C2C2C] mb-4 leading-relaxed">
                  Soluciones legales eficientes para el ritmo de Santiago. Asesoría experta y ágil para proteger sus intereses.
                </p>
                <p className="text-sm text-[#B8935E] font-semibold">Atención presencial disponible</p>
              </CardContent>
            </Card>

            <Card className="border-none shadow-lg bg-white">
              <CardContent className="p-6">
                <div className="w-12 h-12 bg-[#B8935E] rounded-full flex items-center justify-center mb-4">
                  <MapPin className="w-6 h-6 text-white" />
                </div>
                <h3 className="text-xl font-serif font-bold mb-3 text-[#1B3A57]">Región de O'Higgins</h3>
                <p className="text-[#2C2C2C] mb-4 leading-relaxed">
                  Asesoría legal de confianza en el corazón de O'Higgins. Servicio cercano y profesional.
                </p>
                <p className="text-sm text-[#B8935E] font-semibold">Atención presencial estratégica y remota</p>
              </CardContent>
            </Card>

            <Card className="border-none shadow-lg bg-white">
              <CardContent className="p-6">
                <div className="w-12 h-12 bg-[#B8935E] rounded-full flex items-center justify-center mb-4">
                  <MapPin className="w-6 h-6 text-white" />
                </div>
                <h3 className="text-xl font-serif font-bold mb-3 text-[#1B3A57]">Región de Valparaíso</h3>
                <p className="text-[#2C2C2C] mb-4 leading-relaxed">
                  Defensa estratégica en Valparaíso. Experiencia para navegar los desafíos legales de la región.
                </p>
                <p className="text-sm text-[#B8935E] font-semibold">Atención presencial estratégica y remota</p>
              </CardContent>
            </Card>
          </div>
        </div>
      </section>

      {/* Testimonials */}
      <section className="py-16 bg-white">
        <div className="container mx-auto px-4">
          <h2 className="text-3xl md:text-4xl font-serif font-bold text-center mb-12 text-[#1B3A57]">
            Casos de Éxito
          </h2>
          
          <div className="grid md:grid-cols-3 gap-6 max-w-5xl mx-auto">
            <Card className="border-2 border-[#1B3A57]/10">
              <CardContent className="p-6">
                <div className="text-[#B8935E] text-4xl mb-4">"</div>
                <p className="text-[#2C2C2C] mb-4 italic leading-relaxed">
                  Su profesionalismo y empatía hicieron la diferencia en mi caso de divorcio. Me sentí acompañada y bien representada en todo momento.
                </p>
                <div className="border-t pt-4">
                  <p className="font-semibold text-[#1B3A57]">María T.</p>
                  <p className="text-sm text-[#2C2C2C]">Región Metropolitana - Derecho de Familia</p>
                </div>
              </CardContent>
            </Card>

            <Card className="border-2 border-[#1B3A57]/10">
              <CardContent className="p-6">
                <div className="text-[#B8935E] text-4xl mb-4">"</div>
                <p className="text-[#2C2C2C] mb-4 italic leading-relaxed">
                  Excelente asesoría en la redacción de contratos comerciales. Explicaciones claras y atención detallada. Totalmente recomendable.
                </p>
                <div className="border-t pt-4">
                  <p className="font-semibold text-[#1B3A57]">Carlos R.</p>
                  <p className="text-sm text-[#2C2C2C]">Región de O'Higgins - Contratos Privados</p>
                </div>
              </CardContent>
            </Card>

            <Card className="border-2 border-[#1B3A57]/10">
              <CardContent className="p-6">
                <div className="text-[#B8935E] text-4xl mb-4">"</div>
                <p className="text-[#2C2C2C] mb-4 italic leading-relaxed">
                  Logró defender los derechos de mi familia en un caso complejo de herencia. Su conocimiento y dedicación fueron fundamentales.
                </p>
                <div className="border-t pt-4">
                  <p className="font-semibold text-[#1B3A57]">Patricia L.</p>
                  <p className="text-sm text-[#2C2C2C]">Región de Valparaíso - Herencias</p>
                </div>
              </CardContent>
            </Card>
          </div>

          <div className="text-center mt-12">
            <Link href="/casos-de-exito">
              <Button variant="outline" className="border-2 border-[#1B3A57] text-[#1B3A57] hover:bg-[#1B3A57] hover:text-white bg-transparent">
                Ver Más Testimonios
              </Button>
            </Link>
          </div>
        </div>
      </section>

      {/* Contact CTA */}
      <section id="consulta" className="py-16 bg-[#1B3A57] text-white">
        <div className="container mx-auto px-4">
          <div className="max-w-3xl mx-auto text-center">
            <h2 className="text-3xl md:text-4xl font-serif font-bold mb-6">
              Contáctenos Ahora
            </h2>
            <p className="text-xl mb-8 text-[#F5F1E8]/90 leading-relaxed">
              Le contactaremos dentro de 24 horas hábiles. Para casos urgentes, contáctenos directamente por WhatsApp.
            </p>
            
            <div className="grid md:grid-cols-3 gap-6 mb-8">
              <a href="https://wa.me/56912345678" target="_blank" rel="noopener noreferrer" className="block">
                <Card className="border-none hover:shadow-xl transition-shadow cursor-pointer h-full bg-white">
                  <CardContent className="p-6 text-center">
                    <MessageCircle className="w-10 h-10 text-[#25D366] mx-auto mb-3" />
                    <h3 className="font-semibold text-[#1B3A57] mb-2">WhatsApp</h3>
                    <p className="text-sm text-[#2C2C2C]">Respuesta rápida</p>
                  </CardContent>
                </Card>
              </a>

              <a href="tel:+56912345678" className="block">
                <Card className="border-none hover:shadow-xl transition-shadow cursor-pointer h-full bg-white">
                  <CardContent className="p-6 text-center">
                    <Phone className="w-10 h-10 text-[#B8935E] mx-auto mb-3" />
                    <h3 className="font-semibold text-[#1B3A57] mb-2">Teléfono</h3>
                    <p className="text-sm text-[#2C2C2C]">+56 9 1234 5678</p>
                  </CardContent>
                </Card>
              </a>

              <Link href="/contacto">
                <Card className="border-none hover:shadow-xl transition-shadow cursor-pointer h-full bg-white">
                  <CardContent className="p-6 text-center">
                    <Mail className="w-10 h-10 text-[#B8935E] mx-auto mb-3" />
                    <h3 className="font-semibold text-[#1B3A57] mb-2">Email</h3>
                    <p className="text-sm text-[#2C2C2C]">Formulario de contacto</p>
                  </CardContent>
                </Card>
              </Link>
            </div>

            <Link href="/contacto">
              <Button size="lg" className="bg-[#B8935E] hover:bg-[#A07D4A] text-white font-semibold px-8 py-6 text-lg">
                Ir al Formulario de Contacto
              </Button>
            </Link>
          </div>
        </div>
      </section>
    </div>
  )
}
