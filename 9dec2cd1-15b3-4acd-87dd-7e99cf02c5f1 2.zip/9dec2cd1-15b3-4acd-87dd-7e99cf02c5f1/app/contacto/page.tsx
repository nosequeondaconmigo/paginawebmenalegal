'use client'

import React from "react"

import { Card, CardContent } from '@/components/ui/card'
import { Button } from '@/components/ui/button'
import { Input } from '@/components/ui/input'
import { Textarea } from '@/components/ui/textarea'
import { Phone, Mail, MapPin, Clock, MessageCircle } from 'lucide-react'
import { useState } from 'react'

export default function Contacto() {
  const [formData, setFormData] = useState({
    nombre: '',
    email: '',
    telefono: '',
    region: '',
    area: '',
    mensaje: ''
  })
  const [submitted, setSubmitted] = useState(false)

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault()
    // Form submission logic would go here
    setSubmitted(true)
    setTimeout(() => setSubmitted(false), 5000)
  }

  return (
    <div className="min-h-screen">
      {/* Hero Section */}
      <section className="bg-gradient-to-br from-[#1B3A57] to-[#2A4A67] text-white py-16">
        <div className="container mx-auto px-4">
          <div className="max-w-4xl mx-auto text-center">
            <h1 className="text-4xl md:text-5xl font-serif font-bold mb-4 text-balance">
              Contáctenos
            </h1>
            <p className="text-xl text-[#F5F1E8]/90 leading-relaxed">
              Estamos aquí para ayudarle. Le contactaremos dentro de 24 horas hábiles.
            </p>
          </div>
        </div>
      </section>

      {/* Contact Methods */}
      <section className="py-16 bg-[#F5F1E8]">
        <div className="container mx-auto px-4">
          <h2 className="text-3xl md:text-4xl font-serif font-bold text-center mb-12 text-[#1B3A57]">
            Métodos de Contacto
          </h2>
          
          <div className="grid md:grid-cols-3 gap-6 max-w-5xl mx-auto mb-12">
            <a href="https://wa.me/56912345678" target="_blank" rel="noopener noreferrer">
              <Card className="border-none shadow-lg hover:shadow-xl transition-shadow cursor-pointer h-full bg-white">
                <CardContent className="p-8 text-center">
                  <div className="w-16 h-16 bg-[#25D366] rounded-full flex items-center justify-center mx-auto mb-4">
                    <MessageCircle className="w-8 h-8 text-white" />
                  </div>
                  <h3 className="text-xl font-serif font-bold mb-2 text-[#1B3A57]">WhatsApp</h3>
                  <p className="text-[#2C2C2C] mb-2">+56 9 1234 5678</p>
                  <p className="text-sm text-[#B8935E] font-semibold">Respuesta Rápida</p>
                </CardContent>
              </Card>
            </a>

            <a href="tel:+56912345678">
              <Card className="border-none shadow-lg hover:shadow-xl transition-shadow cursor-pointer h-full bg-white">
                <CardContent className="p-8 text-center">
                  <div className="w-16 h-16 bg-[#B8935E] rounded-full flex items-center justify-center mx-auto mb-4">
                    <Phone className="w-8 h-8 text-white" />
                  </div>
                  <h3 className="text-xl font-serif font-bold mb-2 text-[#1B3A57]">Teléfono</h3>
                  <p className="text-[#2C2C2C] mb-2">+56 9 1234 5678</p>
                  <p className="text-sm text-[#B8935E] font-semibold">Llamada Directa</p>
                </CardContent>
              </Card>
            </a>

            <a href="mailto:contacto@menalegal.cl">
              <Card className="border-none shadow-lg hover:shadow-xl transition-shadow cursor-pointer h-full bg-white">
                <CardContent className="p-8 text-center">
                  <div className="w-16 h-16 bg-[#B8935E] rounded-full flex items-center justify-center mx-auto mb-4">
                    <Mail className="w-8 h-8 text-white" />
                  </div>
                  <h3 className="text-xl font-serif font-bold mb-2 text-[#1B3A57]">Email</h3>
                  <p className="text-[#2C2C2C] mb-2 text-sm break-all">contacto@menalegal.cl</p>
                  <p className="text-sm text-[#B8935E] font-semibold">Respuesta en 24hrs</p>
                </CardContent>
              </Card>
            </a>
          </div>

          {/* Office Hours */}
          <Card className="max-w-2xl mx-auto border-2 border-[#1B3A57]/10 bg-white">
            <CardContent className="p-6">
              <div className="flex items-start gap-4">
                <div className="w-12 h-12 bg-[#B8935E] rounded-full flex items-center justify-center flex-shrink-0">
                  <Clock className="w-6 h-6 text-white" />
                </div>
                <div className="flex-1">
                  <h3 className="text-xl font-serif font-bold mb-3 text-[#1B3A57]">
                    Horario de Atención
                  </h3>
                  <div className="space-y-2 text-[#2C2C2C]">
                    <p><strong>Lunes a Viernes:</strong> 9:00 - 19:00</p>
                    <p><strong>Sábado:</strong> 9:00 - 13:00</p>
                    <p><strong>Domingo:</strong> Cerrado</p>
                  </div>
                </div>
              </div>
            </CardContent>
          </Card>
        </div>
      </section>

      {/* Contact Form */}
      <section className="py-16 bg-white">
        <div className="container mx-auto px-4">
          <div className="max-w-3xl mx-auto">
            <h2 className="text-3xl md:text-4xl font-serif font-bold text-center mb-4 text-[#1B3A57]">
              Formulario de Consulta
            </h2>
            <p className="text-center text-[#2C2C2C] mb-8 leading-relaxed">
              Complete el siguiente formulario y nos pondremos en contacto con usted dentro de 24 horas hábiles
            </p>

            {submitted && (
              <div className="mb-6 p-4 bg-green-50 border-2 border-green-500 rounded-lg">
                <p className="text-green-800 font-semibold text-center">
                  ✓ Su consulta ha sido enviada con éxito. Nos pondremos en contacto dentro de 24 horas.
                </p>
              </div>
            )}

            <Card className="border-2 border-[#1B3A57]/10">
              <CardContent className="p-8">
                <form onSubmit={handleSubmit} className="space-y-6">
                  <div>
                    <label htmlFor="nombre" className="block text-sm font-semibold text-[#1B3A57] mb-2">
                      Nombre Completo <span className="text-red-500">*</span>
                    </label>
                    <Input
                      id="nombre"
                      type="text"
                      required
                      value={formData.nombre}
                      onChange={(e) => setFormData({...formData, nombre: e.target.value})}
                      className="h-12"
                      placeholder="Ingrese su nombre completo"
                    />
                  </div>

                  <div className="grid md:grid-cols-2 gap-6">
                    <div>
                      <label htmlFor="email" className="block text-sm font-semibold text-[#1B3A57] mb-2">
                        Correo Electrónico <span className="text-red-500">*</span>
                      </label>
                      <Input
                        id="email"
                        type="email"
                        required
                        value={formData.email}
                        onChange={(e) => setFormData({...formData, email: e.target.value})}
                        className="h-12"
                        placeholder="su.email@ejemplo.com"
                      />
                    </div>

                    <div>
                      <label htmlFor="telefono" className="block text-sm font-semibold text-[#1B3A57] mb-2">
                        Teléfono <span className="text-red-500">*</span>
                      </label>
                      <Input
                        id="telefono"
                        type="tel"
                        required
                        value={formData.telefono}
                        onChange={(e) => setFormData({...formData, telefono: e.target.value})}
                        className="h-12"
                        placeholder="+56 9 1234 5678"
                      />
                    </div>
                  </div>

                  <div className="grid md:grid-cols-2 gap-6">
                    <div>
                      <label htmlFor="region" className="block text-sm font-semibold text-[#1B3A57] mb-2">
                        Región <span className="text-red-500">*</span>
                      </label>
                      <select
                        id="region"
                        required
                        value={formData.region}
                        onChange={(e) => setFormData({...formData, region: e.target.value})}
                        className="w-full h-12 px-3 rounded-md border border-input bg-background"
                      >
                        <option value="">Seleccione una región</option>
                        <option value="metropolitana">Región Metropolitana</option>
                        <option value="ohiggins">Región de O'Higgins</option>
                        <option value="valparaiso">Región de Valparaíso</option>
                      </select>
                    </div>

                    <div>
                      <label htmlFor="area" className="block text-sm font-semibold text-[#1B3A57] mb-2">
                        Área de Interés <span className="text-red-500">*</span>
                      </label>
                      <select
                        id="area"
                        required
                        value={formData.area}
                        onChange={(e) => setFormData({...formData, area: e.target.value})}
                        className="w-full h-12 px-3 rounded-md border border-input bg-background"
                      >
                        <option value="">Seleccione un área</option>
                        <option value="familia">Derecho de Familia</option>
                        <option value="contratos">Contratos Privados</option>
                        <option value="negligencias">Negligencias Médicas</option>
                        <option value="herencias">Herencias y Sucesiones</option>
                      </select>
                    </div>
                  </div>

                  <div>
                    <label htmlFor="mensaje" className="block text-sm font-semibold text-[#1B3A57] mb-2">
                      Mensaje <span className="text-red-500">*</span>
                    </label>
                    <Textarea
                      id="mensaje"
                      required
                      minLength={20}
                      maxLength={500}
                      value={formData.mensaje}
                      onChange={(e) => setFormData({...formData, mensaje: e.target.value})}
                      className="min-h-32"
                      placeholder="Describa brevemente su consulta legal (mínimo 20 caracteres)"
                    />
                    <p className="text-xs text-[#2C2C2C]/60 mt-1">
                      {formData.mensaje.length}/500 caracteres
                    </p>
                  </div>

                  <Button 
                    type="submit" 
                    size="lg" 
                    className="w-full bg-[#B8935E] hover:bg-[#A07D4A] text-white font-semibold h-14 text-lg"
                  >
                    Enviar Consulta
                  </Button>

                  <p className="text-sm text-center text-[#2C2C2C]/60">
                    Al enviar este formulario, usted acepta que nos pongamos en contacto con usted respecto a su consulta legal.
                  </p>
                </form>
              </CardContent>
            </Card>
          </div>
        </div>
      </section>

      {/* Coverage Information */}
      <section className="py-16 bg-[#F5F1E8]">
        <div className="container mx-auto px-4">
          <div className="max-w-5xl mx-auto">
            <h2 className="text-3xl md:text-4xl font-serif font-bold text-center mb-12 text-[#1B3A57]">
              Cobertura de Servicios
            </h2>

            <div className="grid md:grid-cols-3 gap-6">
              <Card className="border-none shadow-lg bg-white">
                <CardContent className="p-6">
                  <div className="w-12 h-12 bg-[#B8935E] rounded-full flex items-center justify-center mb-4">
                    <MapPin className="w-6 h-6 text-white" />
                  </div>
                  <h3 className="text-xl font-serif font-bold mb-3 text-[#1B3A57]">
                    Región Metropolitana
                  </h3>
                  <p className="text-[#2C2C2C] leading-relaxed mb-3">
                    Oficina principal con atención presencial en Santiago.
                  </p>
                  <p className="text-sm font-semibold text-[#B8935E]">
                    ✓ Atención presencial disponible
                  </p>
                </CardContent>
              </Card>

              <Card className="border-none shadow-lg bg-white">
                <CardContent className="p-6">
                  <div className="w-12 h-12 bg-[#B8935E] rounded-full flex items-center justify-center mb-4">
                    <MapPin className="w-6 h-6 text-white" />
                  </div>
                  <h3 className="text-xl font-serif font-bold mb-3 text-[#1B3A57]">
                    Región de O'Higgins
                  </h3>
                  <p className="text-[#2C2C2C] leading-relaxed mb-3">
                    Servicio completo con reuniones estratégicas presenciales y atención remota.
                  </p>
                  <p className="text-sm font-semibold text-[#B8935E]">
                    ✓ Atención remota y presencial estratégica
                  </p>
                </CardContent>
              </Card>

              <Card className="border-none shadow-lg bg-white">
                <CardContent className="p-6">
                  <div className="w-12 h-12 bg-[#B8935E] rounded-full flex items-center justify-center mb-4">
                    <MapPin className="w-6 h-6 text-white" />
                  </div>
                  <h3 className="text-xl font-serif font-bold mb-3 text-[#1B3A57]">
                    Región de Valparaíso
                  </h3>
                  <p className="text-[#2C2C2C] leading-relaxed mb-3">
                    Cobertura completa con reuniones presenciales según necesidad y atención remota.
                  </p>
                  <p className="text-sm font-semibold text-[#B8935E]">
                    ✓ Atención remota y presencial estratégica
                  </p>
                </CardContent>
              </Card>
            </div>
          </div>
        </div>
      </section>
    </div>
  )
}
