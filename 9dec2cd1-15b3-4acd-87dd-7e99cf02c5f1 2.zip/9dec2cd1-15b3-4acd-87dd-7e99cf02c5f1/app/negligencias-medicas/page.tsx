import { Card, CardContent } from '@/components/ui/card'
import { Button } from '@/components/ui/button'
import { Check, Heart, FileText, Shield, AlertTriangle, Scale } from 'lucide-react'
import Link from 'next/link'
import ContactSidebar from '@/components/contact-sidebar'
import {
  Accordion,
  AccordionContent,
  AccordionItem,
  AccordionTrigger,
} from "@/components/ui/accordion"
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs"

export const metadata = {
  title: 'Negligencias Médicas | María de los Ángeles Mena C.',
  description: 'Defensa de derechos del paciente. Negligencias médicas, mala praxis, errores diagnósticos. Servicio en RM, O\'Higgins y Valparaíso.',
}

export default function NegligenciasMedicas() {
  return (
    <div className="min-h-screen">
      {/* Hero Section */}
      <section className="relative bg-gradient-to-br from-[#1B3A57] via-[#2A4A67] to-[#1B3A57] text-white py-20">
        <div className="container mx-auto px-4">
          <div className="max-w-4xl mx-auto text-center">
            <h1 className="text-4xl md:text-5xl font-serif font-bold mb-6 text-balance">
              Negligencias Médicas: Defienda Sus Derechos como Paciente
            </h1>
            <p className="text-xl mb-8 text-[#F5F1E8]/90 leading-relaxed">
              Representación legal especializada en casos de mala práctica médica y defensa de derechos del paciente
            </p>
            <Link href="/contacto">
              <Button size="lg" className="bg-[#B8935E] hover:bg-[#A07D4A] text-white font-semibold px-8 py-6 text-lg">
                Evaluar Mi Caso
              </Button>
            </Link>
          </div>
        </div>
      </section>

      <div className="container mx-auto px-4 py-16">
        <div className="grid lg:grid-cols-3 gap-8">
          {/* Main Content */}
          <div className="lg:col-span-2 space-y-12">
            {/* Marco Legal */}
            <section>
              <h2 className="text-3xl font-serif font-bold mb-6 text-[#1B3A57]">
                Marco Legal en Chile
              </h2>
              <Card className="border-2 border-[#1B3A57]/10">
                <CardContent className="p-6">
                  <p className="text-[#2C2C2C] leading-relaxed mb-4">
                    El sistema chileno distingue entre el sector público y privado en materia de responsabilidad médica:
                  </p>
                  <div className="space-y-4">
                    <div>
                      <h4 className="font-semibold text-[#1B3A57] mb-2">Sector Público</h4>
                      <p className="text-[#2C2C2C] leading-relaxed">
                        Regido por la <strong>falta de servicio</strong> bajo la Ley 19.966 (GES). El Estado responde por el mal funcionamiento del servicio de salud.
                      </p>
                    </div>
                    <div>
                      <h4 className="font-semibold text-[#1B3A57] mb-2">Sector Privado</h4>
                      <p className="text-[#2C2C2C] leading-relaxed">
                        Responsabilidad civil contractual o extracontractual. Se aplica el estándar de <strong>lex artis ad hoc</strong> (nivel de cuidado esperado según las circunstancias específicas).
                      </p>
                    </div>
                  </div>
                </CardContent>
              </Card>
            </section>

            {/* Tipos de Casos */}
            <section>
              <h2 className="text-3xl font-serif font-bold mb-6 text-[#1B3A57]">
                Tipos de Casos que Atendemos
              </h2>
              <div className="grid md:grid-cols-2 gap-4">
                {[
                  { icon: AlertTriangle, title: 'Errores de Diagnóstico', desc: 'Diagnóstico tardío o incorrecto' },
                  { icon: Heart, title: 'Errores Quirúrgicos', desc: 'Procedimientos mal ejecutados' },
                  { icon: FileText, title: 'Errores Obstétricos', desc: 'Daños durante parto' },
                  { icon: Shield, title: 'Errores de Medicación', desc: 'Dosis incorrectas o interacciones' },
                  { icon: AlertTriangle, title: 'Infecciones Nosocomiales', desc: 'Infecciones adquiridas en hospital' },
                  { icon: Scale, title: 'Pérdida de Oportunidad', desc: 'Tratamiento no oportuno' },
                ].map((caso, idx) => (
                  <Card key={idx} className="border-2 border-[#1B3A57]/10 hover:border-[#B8935E] transition-colors">
                    <CardContent className="p-4">
                      <div className="flex items-start gap-3">
                        <div className="w-10 h-10 bg-[#B8935E]/10 rounded-full flex items-center justify-center flex-shrink-0">
                          <caso.icon className="w-5 h-5 text-[#B8935E]" />
                        </div>
                        <div>
                          <h3 className="font-semibold text-[#1B3A57] mb-1">{caso.title}</h3>
                          <p className="text-sm text-[#2C2C2C]">{caso.desc}</p>
                        </div>
                      </div>
                    </CardContent>
                  </Card>
                ))}
              </div>
            </section>

            {/* Servicios */}
            <section>
              <h2 className="text-3xl font-serif font-bold mb-6 text-[#1B3A57]">
                Nuestros Servicios
              </h2>
              <div className="space-y-3">
                {[
                  'Evaluación gratuita de viabilidad del caso',
                  'Obtención y análisis de ficha clínica completa',
                  'Coordinación de informes periciales médicos',
                  'Reclamo ante establecimiento de salud',
                  'Mediación obligatoria (CDE o Superintendencia de Salud)',
                  'Demanda judicial por daños y perjuicios',
                  'Representación en procedimientos penales cuando corresponda',
                  'Gestión ante aseguradoras y seguros médicos',
                ].map((servicio, idx) => (
                  <Card key={idx} className="border-l-4 border-[#B8935E]">
                    <CardContent className="p-4">
                      <div className="flex items-start gap-3">
                        <Check className="w-5 h-5 text-[#B8935E] mt-0.5 flex-shrink-0" />
                        <p className="text-[#2C2C2C]">{servicio}</p>
                      </div>
                    </CardContent>
                  </Card>
                ))}
              </div>
            </section>

            {/* Proceso */}
            <section>
              <h2 className="text-3xl font-serif font-bold mb-6 text-[#1B3A57]">
                Nuestro Proceso
              </h2>
              <div className="space-y-4">
                {[
                  { step: '1', title: 'Evaluación Inicial', desc: 'Análisis gratuito de viabilidad del caso', time: 'Inmediato' },
                  { step: '2', title: 'Recopilación de Antecedentes', desc: 'Solicitud de ficha clínica y documentación', time: '2-4 semanas' },
                  { step: '3', title: 'Informe Pericial', desc: 'Evaluación por médico especialista', time: '4-8 semanas' },
                  { step: '4', title: 'Mediación', desc: 'Procedimiento obligatorio previo', time: '2-4 meses' },
                  { step: '5', title: 'Demanda Judicial', desc: 'Presentación ante tribunales si no hay acuerdo', time: 'Variable' },
                  { step: '6', title: 'Juicio y Sentencia', desc: 'Representación integral hasta fallo definitivo', time: '12-36 meses' },
                ].map((paso) => (
                  <Card key={paso.step} className="border-l-4 border-[#B8935E]">
                    <CardContent className="p-4">
                      <div className="flex gap-4">
                        <div className="w-10 h-10 bg-[#B8935E] text-white rounded-full flex items-center justify-center font-bold flex-shrink-0">
                          {paso.step}
                        </div>
                        <div className="flex-1">
                          <div className="flex items-start justify-between gap-2 mb-1">
                            <h3 className="font-semibold text-[#1B3A57]">{paso.title}</h3>
                            <span className="text-xs bg-[#F5F1E8] px-2 py-1 rounded text-[#2C2C2C] whitespace-nowrap">
                              {paso.time}
                            </span>
                          </div>
                          <p className="text-sm text-[#2C2C2C]">{paso.desc}</p>
                        </div>
                      </div>
                    </CardContent>
                  </Card>
                ))}
              </div>
            </section>

            {/* Regional Messaging */}
            <section>
              <h2 className="text-3xl font-serif font-bold mb-6 text-[#1B3A57]">
                Servicio por Región
              </h2>
              <Tabs defaultValue="metropolitana" className="w-full">
                <TabsList className="grid w-full grid-cols-3">
                  <TabsTrigger value="metropolitana">RM</TabsTrigger>
                  <TabsTrigger value="ohiggins">O'Higgins</TabsTrigger>
                  <TabsTrigger value="valparaiso">Valparaíso</TabsTrigger>
                </TabsList>
                <TabsContent value="metropolitana">
                  <Card>
                    <CardContent className="p-6">
                      <h3 className="font-semibold text-[#1B3A57] mb-3">Región Metropolitana</h3>
                      <p className="text-[#2C2C2C] leading-relaxed">
                        Representación experta en casos contra clínicas y hospitales de Santiago. Conocimiento profundo de los principales centros de salud y su funcionamiento. Atención presencial y seguimiento cercano de su caso.
                      </p>
                    </CardContent>
                  </Card>
                </TabsContent>
                <TabsContent value="ohiggins">
                  <Card>
                    <CardContent className="p-6">
                      <h3 className="font-semibold text-[#1B3A57] mb-3">Región de O'Higgins</h3>
                      <p className="text-[#2C2C2C] leading-relaxed">
                        Defensa integral de derechos del paciente en O'Higgins. Experiencia con hospitales regionales y centros de salud locales. Coordinación eficiente de pericias y procedimientos judiciales.
                      </p>
                    </CardContent>
                  </Card>
                </TabsContent>
                <TabsContent value="valparaiso">
                  <Card>
                    <CardContent className="p-6">
                      <h3 className="font-semibold text-[#1B3A57] mb-3">Región de Valparaíso</h3>
                      <p className="text-[#2C2C2C] leading-relaxed">
                        Asesoría especializada en negligencias médicas en Valparaíso y Viña del Mar. Conocimiento de la red asistencial regional. Representación completa desde mediación hasta juicio.
                      </p>
                    </CardContent>
                  </Card>
                </TabsContent>
              </Tabs>
            </section>

            {/* FAQs */}
            <section>
              <h2 className="text-3xl font-serif font-bold mb-6 text-[#1B3A57]">
                Preguntas Frecuentes
              </h2>
              <Accordion type="single" collapsible className="w-full">
                <AccordionItem value="item-1">
                  <AccordionTrigger className="text-left">
                    ¿Cómo sé si tengo un caso de negligencia médica?
                  </AccordionTrigger>
                  <AccordionContent>
                    <p className="text-[#2C2C2C] leading-relaxed">
                      Un caso viable requiere: 1) Un daño comprobable, 2) Desviación del estándar de cuidado médico, 3) Relación causal entre la conducta y el daño. Ofrecemos evaluación gratuita para determinar viabilidad.
                    </p>
                  </AccordionContent>
                </AccordionItem>
                <AccordionItem value="item-2">
                  <AccordionTrigger className="text-left">
                    ¿Cuánto tiempo tengo para reclamar?
                  </AccordionTrigger>
                  <AccordionContent>
                    <p className="text-[#2C2C2C] leading-relaxed">
                      El plazo de prescripción es de 4 años desde que se produce el daño (o desde que se conoce) en materia civil. Es crucial actuar rápidamente para preservar evidencia médica.
                    </p>
                  </AccordionContent>
                </AccordionItem>
                <AccordionItem value="item-3">
                  <AccordionTrigger className="text-left">
                    ¿Qué documentos necesito?
                  </AccordionTrigger>
                  <AccordionContent>
                    <p className="text-[#2C2C2C] leading-relaxed">
                      Ficha clínica completa, exámenes, imágenes médicas, órdenes de procedimientos, consentimientos informados, comprobantes de gastos médicos, y licencias médicas. Nosotros podemos solicitar oficialmente la documentación al centro de salud.
                    </p>
                  </AccordionContent>
                </AccordionItem>
                <AccordionItem value="item-4">
                  <AccordionTrigger className="text-left">
                    ¿Cuánto cuesta un caso de negligencia médica?
                  </AccordionTrigger>
                  <AccordionContent>
                    <p className="text-[#2C2C2C] leading-relaxed">
                      Trabajamos con sistema de honorarios por éxito en casos seleccionados. La evaluación inicial es gratuita. Conversaremos transparentemente sobre costos y estructura de honorarios según su caso específico.
                    </p>
                  </AccordionContent>
                </AccordionItem>
                <AccordionItem value="item-5">
                  <AccordionTrigger className="text-left">
                    ¿Es obligatoria la mediación?
                  </AccordionTrigger>
                  <AccordionContent>
                    <p className="text-[#2C2C2C] leading-relaxed">
                      Sí, antes de demandar judicialmente es obligatorio pasar por mediación ante el CDE (sector público) o Superintendencia de Salud (sector privado). Este proceso puede resultar en acuerdo extrajudicial favorable.
                    </p>
                  </AccordionContent>
                </AccordionItem>
              </Accordion>
            </section>

            {/* CTA */}
            <Card className="border-2 border-[#B8935E] bg-[#F5F1E8]">
              <CardContent className="p-8 text-center">
                <h3 className="text-2xl font-serif font-bold mb-4 text-[#1B3A57]">
                  ¿Sufrió un Daño por Negligencia Médica?
                </h3>
                <p className="text-[#2C2C2C] mb-6 leading-relaxed">
                  Evaluación gratuita de su caso. Defienda sus derechos como paciente.
                </p>
                <Link href="/contacto">
                  <Button size="lg" className="bg-[#B8935E] hover:bg-[#A07D4A] text-white font-semibold">
                    Evaluar Mi Caso Gratis
                  </Button>
                </Link>
              </CardContent>
            </Card>
          </div>

          {/* Sidebar */}
          <div className="lg:col-span-1">
            <ContactSidebar />
          </div>
        </div>
      </div>
    </div>
  )
}
